package com.mail.myapplication.ui.create

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.MyApp
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.hone.HomeListFrg
import com.mail.myapplication.ui.hone.ImageAdapter
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator
import java.util.ArrayList

class SelectTagAty:BaseXAty() {

    lateinit var mBinding: AtySelectTabBinding

    var list_frg = ArrayList<BaseXFrg>()
    var list_tab = ArrayList<MutableMap<String,String>>()
    var home = Home()
    var mMyApp : MyApp?=null

    override fun initView() {
        mMyApp =application as MyApp?
        mMyApp?.list_select?.clear()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a1( this)
    }


    override fun getLayoutView(): View {
        mBinding = AtySelectTabBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "设置标签"
            include.tvRight.text = "确认"
            include.tvRight.visibility = View.VISIBLE


            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }

            })
        }
    }


    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "tag/list") {

            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list_tab = JSONUtils.parseKeyAndValueToMapList(str)

                for ( i in list_tab.indices){
                    list_frg.add(SelectTagFrg.create(list_tab[i]["son_tag_list"].toString()))
                }

                mBinding.vp.adapter = MyPagerAdapter(supportFragmentManager)
                mBinding.layoutTab.setViewPager(mBinding.vp)
                mBinding.vp.offscreenPageLimit = list_frg.size
            } else {

                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)

            }
        }

    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "tag/list"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.tv_right -> {
                if ( mMyApp!!.list_select.size == 0){
                    showToastS("请选择标签")
                    return
                }
                var tag_id_list = ArrayList<String>()
                var tag_name_list = ArrayList<String>()

                for ( i in mMyApp!!.list_select.indices){
                    tag_id_list.add( mMyApp!!.list_select[i]["id"].toString())
                    tag_name_list.add( mMyApp!!.list_select[i]["name"].toString())
                }

                var intent = Intent()
                intent.putExtra("tag_name", tag_name_list)
                intent.putExtra("tag_id", tag_id_list)
                setResult(RESULT_OK, intent)
                finish()
            }
        }
    }

    inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

        var mFragmentManager: FragmentManager

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

        override fun getPageTitle(position: Int) = list_tab[position]["name"]

        override fun getItemPosition(`object`: Any) = POSITION_NONE

        init {
            mFragmentManager = fm
        }

    }



}