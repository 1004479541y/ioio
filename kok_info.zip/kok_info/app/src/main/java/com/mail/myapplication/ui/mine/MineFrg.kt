package com.mail.myapplication.ui.mine

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgHomeBinding
import com.mail.myapplication.databinding.FrgMineBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.create.CreateTravelAty
import com.mail.myapplication.ui.create.PostImgAty
import com.mail.myapplication.ui.hone.search.SearchAty
import com.mail.myapplication.ui.mine.opus.OpusAty
import com.mail.myapplication.ui.page.OtherPageAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import java.util.ArrayList

class MineFrg:BaseXFrg() {

    lateinit var mBinding: FrgMineBinding

    var home = Home()

    override fun getLayoutId(): Int = 0


    override fun getLayoutView(): View {
        mBinding = FrgMineBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onResume() {
        super.onResume()
        home.a12(this)
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        mBinding.swipeRefreshLayout.finishLoadmore()
        mBinding.swipeRefreshLayout.finishRefreshing()
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        mBinding.swipeRefreshLayout.finishLoadmore()
        mBinding.swipeRefreshLayout.finishRefreshing()
        if (type == "user/info"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data = JSONUtils.parseKeyAndValueToMap(str)

                var maxW = AutoLayoutConifg.getInstance().screenWidth/3
                ImageLoader.loadImageAes(requireActivity() ,map_data["avatar"],mBinding.ivHead,maxW,maxW)
                MyUtils3.setVipLevel2(map_data["vip_level"], mBinding.imgvFrame,mBinding.framlayHead,0)

                mBinding.tvNick.text = map_data["nick"]
                mBinding.tvFollow.text = map_data["flow"]
                mBinding.tvFans.text = map_data["fans"]
                mBinding.tvCollect.text = map_data["collect"]
                mBinding.tvZan.text = map_data["like"]

                if (map_data["vip_level"] == "0"){
                    mBinding.tvDes.visibility = View.VISIBLE
                    mBinding.tvDes.text = map_data["play_num_notice"]
                    mBinding.tvVipDes.text = "你还未开通VIP，立即开通>>"
                }else{
                    mBinding.tvDes.visibility = View.GONE

                    var time =  (TimeUtils.getTime(map_data["vip_expired"]).toDouble()
                            - TimeUtils.getBeijinTime().toDouble())/1000
                    mBinding.tvVipDes.text = TimeUtils.
                    formatSecond1(time).replace("前","后")+"到期，立即续期>>"
                }


                when(map_data["gender"]){

                    "1" ->{
                        mBinding.imgvGender.visibility = View.VISIBLE
                        mBinding.imgvGender.setImageResource(R.drawable.ic_54)
                    }
                    "2" ->{
                        mBinding.imgvGender.visibility = View.VISIBLE
                        mBinding.imgvGender.setImageResource(R.drawable.ic_104)
                    }
                    else->{
                        mBinding.imgvGender.visibility = View.GONE
                    }

                }


            }
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        mBinding.linlayOpus.setOnClickListener {
            startActivity(OpusAty::class.java)
        }

        mBinding.relayMine.setOnClickListener {
            startActivity(OtherPageAty::class.java)
        }

        with(mBinding){
            swipeRefreshLayout.setEnableLoadmore(false)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setIsPinContentView(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    home.a12(this@MineFrg)
                }

                override fun loadMoreStart() {
                }

            })

        }
    }

}