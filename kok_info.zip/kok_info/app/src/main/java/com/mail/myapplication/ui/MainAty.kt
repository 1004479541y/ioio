package com.mail.myapplication.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.mail.comm.utils.FileSizeUtil
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMainBinding
import com.mail.myapplication.ui.create.CreateFrg
import com.mail.myapplication.ui.hone.HomeFrg
import com.mail.myapplication.ui.mine.MineFrg
import com.mail.myapplication.ui.post.PostFrg
import com.mail.myapplication.ui.video.VideoFrg
import org.xutils.common.util.LogUtil

class MainAty() : BaseXAty() {

    lateinit var mBinding: AtyMainBinding

    var list_tv: Array<TextView>? = null
    var list_imgv: Array<ImageView>? = null
    var position: Int = 0

    override fun initView() {
        list_tv = arrayOf(mBinding.tv01, mBinding.tv02, mBinding.tv03, mBinding.tv04, mBinding.tv05)
        list_imgv = arrayOf(mBinding.imgv01, mBinding.imgv02, mBinding.imgv03, mBinding.imgv04,mBinding.imgv05)
    }

    override fun requestData() {}

    override fun getFragmentContainerId(): Int = R.id.fralay_content

    override fun getLayoutView(): View {
        mBinding = AtyMainBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setStatusColor("#000000")
//        setAndroidNativeLightStatusBar(false)
        addFragment(HomeFrg::class.java, null)
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.linlay_01 -> {
                position = 0
                list_tv?.let { t1 -> list_imgv?.let { t2 -> setSelector(mBinding.tv01, t1, t2) } }
                addFragment(HomeFrg::class.java, null)
            }

            R.id.linlay_02 -> {
                position = 1
                list_tv?.let { t1 -> list_imgv?.let { t2 -> setSelector(mBinding.tv02, t1, t2) } }
                addFragment(VideoFrg::class.java, null)

            }

            R.id.linlay_03 -> {
                position = 2
                list_tv?.let { t1 -> list_imgv?.let { t2 -> setSelector(mBinding.tv03, t1, t2) } }
                addFragment(PostFrg::class.java, null)

            }

            R.id.linlay_04 -> {
                position = 3
                list_tv?.let { t1 -> list_imgv?.let { t2 -> setSelector(mBinding.tv04, t1, t2) } }
                addFragment(CreateFrg::class.java, null)

            }

            R.id.linlay_05 -> {
                position = 4
                list_tv?.let { t1 -> list_imgv?.let { t2 -> setSelector(mBinding.tv05, t1, t2) } }
                addFragment(MineFrg::class.java, null)

            }

        }
    }

    private fun setSelector(tv: TextView, list_tv: Array<TextView>, list_imgv: Array<ImageView>) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(resources.getColor(R.color.c_6))
                when (i) {
                    0 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab1_checked)
                    1 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab2_checked)
                    2 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab3_checked)
                    3 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab4_checked)
                    4 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab5_checked)
                }
            } else {
                list_tv[i].setTextColor(resources.getColor(R.color.mainnocheck))
                when (i) {
                    0 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab1_normal)
                    1 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab2_normal)
                    2 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab3_normal)
                    3 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab4_normal)
                    4 -> list_imgv[i].setImageResource(R.drawable.ic_main_tab5_normal)
                }
            }
        }
    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//
//        LogUtil.e("onActivityResultddddddd")
//        if (resultCode != RESULT_OK) {
//            LogUtil.e("onActivityResultddddddd2")
//
//            return
//        }
//        LogUtil.e("onActivityResultddddddd3:"+requestCode)
//
//        when (requestCode) {
//
//            400 -> {
//
//                var path = data?.getStringExtra("data")
//                var size = FileSizeUtil.getFileOrFilesSize(path, FileSizeUtil.SIZETYPE_MB)
//                showToastS(path)
//                LogUtil.e("onActivityResultddddddd2"+path)
//
//
//            }
//        }
//    }


}