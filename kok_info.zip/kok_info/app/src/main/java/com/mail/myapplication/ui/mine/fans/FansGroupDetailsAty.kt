package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyFansGroupDetailsBinding
import com.mail.myapplication.databinding.ItemFansGroupDetailsBinding
import com.yhz.adaptivelayout.utils.AutoUtils

class FansGroupDetailsAty : BaseXAty() {

    lateinit var mBinding: AtyFansGroupDetailsBinding


    var mAdapter: GoldRecyclerAdapter? = null


    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupDetailsBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTopview2(mBinding.include.relayTopBg, resources.getString(R.string.c_4))

        mBinding.include.tvTitle.text = "user_name"

        var mLayoutManager2 = GridLayoutManager(this, 1)
        mLayoutManager2.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager2
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        with(mBinding){
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                }

                override fun loadMoreStart() {
                }

            })

            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

        }

    }




    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }
            R.id.relay_fans_group_intro ->{
                startActivity(FansGroupIntroAty::class.java)
            }


        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemFansGroupDetailsBinding.inflate(LayoutInflater.from(this@FansGroupDetailsAty)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                }

            }

        }

        inner class fGoldViewHolder(binding: ItemFansGroupDetailsBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemFansGroupDetailsBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }


}