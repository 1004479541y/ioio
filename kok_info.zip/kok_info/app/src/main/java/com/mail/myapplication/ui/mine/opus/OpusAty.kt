package com.mail.myapplication.ui.mine.opus

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.create.CreateFrg
import com.mail.myapplication.ui.hone.HomeFrg
import com.mail.myapplication.ui.post.PostFrg
import com.mail.myapplication.ui.video.VideoFrg
import com.yhz.adaptivelayout.utils.AutoUtils

class OpusAty : BaseXAty() {

    lateinit var mBinding: AtyOpusBinding
    var list_tv: Array<TextView>? = null
    var position: Int = -1
    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyOpusBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getFragmentContainerId(): Int = R.id.fralay_content


    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "我的作品"
            linlay01.performClick()
        }

    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.linlay_01 -> {
                if (position == 0){
                    mBinding.linlayDg.visibility = View.VISIBLE
                    return
                }
                mBinding.linlayDg.visibility = View.GONE
                position = 0
                list_tv?.let { t1 ->setSelector(mBinding.tv01, t1) }
                addFragment(OpusLongVideoFrg::class.java, null)
            }

            R.id.linlay_02 -> {
                if (position == 1){
                    mBinding.linlayDg.visibility = View.VISIBLE
                    return
                }
                mBinding.linlayDg.visibility = View.GONE
                position = 1
                list_tv?.let { t1 ->setSelector(mBinding.tv02, t1) }
                addFragment(VideoFrg::class.java, null)

            }

            R.id.linlay_03 -> {
                if (position == 2){
                    mBinding.linlayDg.visibility = View.VISIBLE
                    return
                }
                mBinding.linlayDg.visibility = View.GONE

                position = 2
                list_tv?.let { t1 ->setSelector(mBinding.tv03, t1) }
                addFragment(OpusHeJiFrg::class.java, null)

            }

            R.id.linlay_04 -> {
                if (position == 3){
                    mBinding.linlayDg.visibility = View.VISIBLE
                    return
                }
                mBinding.linlayDg.visibility = View.GONE

                position = 3
                list_tv?.let { t1 ->setSelector(mBinding.tv04, t1) }
                addFragment(OpusHeJiFrg::class.java, null)

            }

            R.id.v_hide ->{
                mBinding.linlayDg.visibility = View.GONE
            }


        }
    }

    private fun setSelector(tv: TextView, list_tv: Array<TextView>) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor("#000000"))

            } else {
                list_tv[i].setTextColor(Color.parseColor("#7a7a7a"))
            }
        }
    }



}