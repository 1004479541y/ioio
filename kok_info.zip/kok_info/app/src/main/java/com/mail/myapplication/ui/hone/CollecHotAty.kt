package com.mail.myapplication.ui.hone

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.hone.ImageAdapter
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.mail.myapplication.ui.page.OtherPageFrg
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class CollecHotAty:BaseXAty() {

    lateinit var mBinding: AtyCollecHotBinding

    lateinit var list_tv: Array<TextView>

    lateinit var list_v: Array<View>

    var list_frg =  ArrayList<BaseXFrg>()


    override fun initView() {

        with(mBinding){
            list_tv = arrayOf(tv01,tv02)
            list_v = arrayOf(v01,v02)
        }

    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtyCollecHotBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "精选合集"

            linlay001.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay02.setOnClickListener {
                viewPager.setCurrentItem(1,true)

            }

            list_frg.add(CollecHotFrg.create("1"))
            list_frg.add(CollecHotFrg.create("2"))

            viewPager.adapter = HomeListAdataper(supportFragmentManager, lifecycle, list_frg)

            viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when(position){

                        0 -> {
                            setSelector(tv01)
                        }

                        1 -> {
                            setSelector(tv02)
                        }

                    }
                }
            })

        }
    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor("#000000"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗


                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(55).toFloat())
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor("#999999"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }


    fun mainClick(v: View) {

        when (v.id) {


            R.id.relay_back -> {
                finish()
            }
        }
    }


    inner class HomeListAdataper(fa: FragmentManager, lifecycle: Lifecycle, val list: ArrayList<BaseXFrg>) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int =list.size

        override fun createFragment(position: Int): Fragment = list[position]

    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemSelectCollecBinding.inflate(LayoutInflater.from(this@CollecHotAty)))

        }

        override fun getItemCount(): Int = 5

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {


        }



        inner class fGoldViewHolder(binding: ItemSelectCollecBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemSelectCollecBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }



}