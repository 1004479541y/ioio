package com.mail.myapplication.interfaces

import android.text.TextUtils
import com.mail.comm.app.AppConfig
import com.mail.comm.net.ApiTool
import com.mail.comm.net.DataManager
import com.mail.comm.utils.MyUtils2
import com.yhz.adaptivelayout.abs.ApiListener
import org.xutils.http.RequestParams
import java.io.File

class Home {


    fun a1(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/tag/lists")
        ApiTool().postApi2(params, apiListener, "tag/list")
    }

    fun a2(page: Int, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/home/recommend")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        ApiTool().postApi2(params, apiListener, "home/list")
    }

    fun a3(position: String,related_id:String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/ad/list")
        params.addBodyParameter("position", position)
        if (!TextUtils.isEmpty(related_id)){
            params.addBodyParameter("related_id", related_id)
        }
        ApiTool().postApi2(params, apiListener, "ad/list")
    }

    fun a4(title: String,cover:String, is_fans:String,file_path:String,
           coins:String, type_ids:String,album_id:String,video_type:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/create")
        params.addBodyParameter("title", title)
        params.addBodyParameter("cover", cover)
        params.addBodyParameter("is_fans", is_fans)
        params.addBodyParameter("file_path", file_path)
        if (!TextUtils.isEmpty(coins)){
            params.addBodyParameter("coins", coins)
        }
        params.addBodyParameter("type_ids", type_ids)

        if (!TextUtils.isEmpty(album_id)){
            params.addBodyParameter("album_id", album_id)
        }
        params.addBodyParameter("video_type", video_type)

        ApiTool().postApi2(params, apiListener, "video/create")
    }

    //文件上传
    fun a5(path: String, apiListener: ApiListener) {
        val timeStamp: String = (System.currentTimeMillis() / 1000).toString()
        val singPostBody = DataManager.singFileBody(timeStamp + "")
        var url = AppConfig.upload_url + "/upload?" + "platform=A&timestamp=" + timeStamp + "&dir=user&sign=" + singPostBody
        val params = RequestParams(url)
        params.isMultipart = true
        params.readTimeout = 1000 * 60 * 5
        params.addBodyParameter("file", File(path), "multipart/form-data")
        ApiTool().postApiFile(params, apiListener, "file/upload")
    }

    fun a6(page: Int, uid:String,keywords:String,status:String,orderBy:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/album/lists")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(uid)){
            params.addBodyParameter("uid", uid)
        }
        if (!TextUtils.isEmpty(keywords)){
            params.addBodyParameter("keywords", keywords)
        }
        if (!TextUtils.isEmpty(orderBy)){
            params.addBodyParameter("orderBy", orderBy)
        }
        if (!TextUtils.isEmpty(status)){
            params.addBodyParameter("status", status)
        }
        ApiTool().postApi2(params, apiListener, "album/list")
    }




    fun a7(page: Int, user_id:String,type:String,status:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/user/list")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "20")
        if (!TextUtils.isEmpty(user_id)){
            params.addBodyParameter("user_id", user_id)
        }
        params.addBodyParameter("type", type)

        if (!TextUtils.isEmpty(status)){
            params.addBodyParameter("status", status)
        }
        ApiTool().postApi2(params, apiListener, "video/list")
    }


    fun a8(cover: String,title:String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/album/create")
        params.addBodyParameter("cover", cover)
        params.addBodyParameter("title", title)
        ApiTool().postApi2(params, apiListener, "album/create")
    }


    //文件上传
    fun a9(path: String, apiListener: ApiListener) {
        val timeStamp: String = (System.currentTimeMillis() / 1000).toString()
        val singPostBody = DataManager.singFileBody(timeStamp + "")
        var url = AppConfig.upload_url + "/upload?" + "platform=A&timestamp=" + timeStamp + "&dir=user&sign=" + singPostBody
        val params = RequestParams(url)
        params.isMultipart = true
        params.readTimeout = 1000 * 60 * 5
        params.addBodyParameter("file", File(path), "multipart/form-data")
        ApiTool().postApiFile(params, apiListener, "file/upload2")
    }


    fun a10(id: String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/info")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "video/info")
    }


    fun a11(id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/recommend")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "video/recommend")
    }

    fun a12(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/user/info")
        ApiTool().postApi2(params, apiListener, "user/info")
    }

    //评论列表
    fun a13(page: Int, id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/comment/lists")
        params.addBodyParameter("page", page)
        params.addBodyParameter("page_size", "20")
        params.addBodyParameter("module", "forum")
        params.addBodyParameter("svalue", id)
        params.addBodyParameter("parent_id", "0")
        ApiTool().postApi2(params, apiListener, "comment/list")
    }

    fun a14(page: Int, type_id:String,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/list/type")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "10")
        params.addBodyParameter("type_id", type_id)
        ApiTool().postApi2(params, apiListener, "home/list")
    }


    fun a15(page: Int,apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/video/home/follow")
        params.addBodyParameter("page", page.toString())
        params.addBodyParameter("page_size", "10")
        ApiTool().postApi2(params, apiListener, "home/list")
    }

    fun a64(id: String, apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/ad/count")
        params.addBodyParameter("id", id)
        ApiTool().postApi2(params, apiListener, "ad/count")
    }

    fun a42(apiListener: ApiListener) {
        val params = RequestParams(AppConfig.Host_Url + "/app/api/site/version")
        params.addQueryStringParameter("device_type", "A")
        params.addQueryStringParameter("version_code", MyUtils2.getAppVersionName())
        ApiTool().getApi(params, apiListener, "version/update")
    }

}