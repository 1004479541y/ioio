package com.mail.myapplication.ui.create

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMainBinding
import com.mail.myapplication.databinding.AtyPostImgBinding
import com.mail.myapplication.databinding.AtyPostVideoBinding

class PostImgAty:BaseXAty() {

    lateinit var mBinding: AtyPostImgBinding

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtyPostImgBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "发布"

            include.tvRight.text = "发布"
            include.tvRight.visibility = View.VISIBLE
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_select_collec -> {
                startActivity(SelectCollecAty::class.java)
            }
            R.id.relay_back -> {
                finish()
            }
        }
    }

}