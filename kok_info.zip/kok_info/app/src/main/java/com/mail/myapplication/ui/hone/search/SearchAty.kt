package com.mail.myapplication.ui.hone.search

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.databinding.*
import com.yhz.adaptivelayout.utils.AutoUtils

class SearchAty:BaseXAty() {

    lateinit var mBinding: AtySearchBinding
    lateinit var mAdapterHot: GoldHotRecyclerAdapter
    lateinit var mAdapterLog: GoldLogRecyclerAdapter


    override fun initView() {
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtySearchBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(this@SearchAty, 5)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerviewHot.layoutManager = mLayoutManager2
            mAdapterHot = GoldHotRecyclerAdapter()
            recyclerviewHot.adapter = mAdapterHot

            var mLayoutManager = GridLayoutManager(this@SearchAty, 2)
            mLayoutManager.orientation = RecyclerView.VERTICAL
            recyclerviewLog.layoutManager = mLayoutManager
            mAdapterLog = GoldLogRecyclerAdapter()
            recyclerviewLog.adapter = mAdapterLog

        }


    }

    inner class GoldHotRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemSearchHotBinding.inflate(LayoutInflater.from(this@SearchAty)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        }


        inner class fGoldViewHolder(binding: ItemSearchHotBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemSearchHotBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

    inner class GoldLogRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemSearchLogBinding.inflate(LayoutInflater.from(this@SearchAty)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        }


        inner class fGoldViewHolder(binding: ItemSearchLogBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemSearchLogBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}