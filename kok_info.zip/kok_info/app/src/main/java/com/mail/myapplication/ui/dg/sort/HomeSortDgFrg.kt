package com.mail.myapplication.ui.dg.sort

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.view.*
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.comm.base.BaseAty
import com.mail.comm.base.BaseDgFrg
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import java.util.ArrayList

class HomeSortDgFrg  : BaseDgFrg()  {

    lateinit var mBinding: DgHomeSortBinding
    private var baseAty = context
    var type ="1"
    var id =""
    var listener : RechargeListen? =null

    var list_frg = ArrayList<BaseXFrg>()
    var list_tab = ArrayList<String>()

    override fun getLayoutId()=0

    override fun getDialogStyle(): Int = R.style.dialogFullscreen3

    override fun getLayoutView(): View {
        mBinding = DgHomeSortBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun canCancel(): Boolean =true

    override fun setWindowAttributes(window: Window?) {
    }


    @SuppressLint("MissingSuperCall")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list_frg.add(HomeSortListFrg.create("1"))
        list_frg.add(HomeSortListFrg.create("1"))
        list_frg.add(HomeSortListFrg.create("1"))
        list_frg.add(HomeSortListFrg.create("1"))
        list_tab.add("关注")
        list_tab.add("推荐")
        list_tab.add("原创")
        list_tab.add("日韩")

        mBinding.vp.setAdapter( MyPagerAdapter(childFragmentManager))
        mBinding.layoutTab.setViewPager(mBinding.vp)
        mBinding.vp.setOffscreenPageLimit(list_frg.size)

        mBinding.imgvCancel.setOnClickListener {
            dismiss()
        }
    }

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        mBinding = DgHomeSortBinding.inflate(layoutInflater);
//        setContentView(mBinding.root)
//        window?.setWindowAnimations(R.style.dialogFullscreen3)
//        val dialogWindow = window
//        dialogWindow!!.setBackgroundDrawable(null)
//        dialogWindow.setGravity(Gravity.BOTTOM)
//        setCanceledOnTouchOutside(true)
//        val m = baseAty.windowManager
//        val d = m.defaultDisplay// 获取屏幕宽、高
//        val p = dialogWindow.attributes
//        window?.getDecorView()?.setPadding(0, 0, 0, 0)
//        p.height =  ((d.height * 0.8).toInt()) // 高度设置为屏幕的0.6
//        p.width = (d.width * 1) // 宽度设置为屏幕的0.85
//        dialogWindow.attributes = p
//
//
//        list_frg.add(HomeSortListFrg.create("1"))
//        list_frg.add(HomeSortListFrg.create("1"))
//        list_frg.add(HomeSortListFrg.create("1"))
//        list_frg.add(HomeSortListFrg.create("1"))
//        list_tab.add("关注")
//        list_tab.add("推荐")
//        list_tab.add("原创")
//        list_tab.add("日韩")
//
//        mBinding.vp.setAdapter( MyPagerAdapter(baseAty.supportFragmentManager))
//        mBinding.layoutTab.setViewPager(mBinding.vp)
//        mBinding.vp.setOffscreenPageLimit(list_frg.size)
//
//        mBinding.imgvCancel.setOnClickListener {
//            dismiss()
//        }
//    }


    inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
        var mFragmentManager: FragmentManager

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

        override fun getPageTitle(position: Int) = list_tab[position]

        override fun getItemPosition(`object`: Any) = POSITION_NONE

        init {
            mFragmentManager = fm
        }
    }
    fun setData(id:String ){
        this.id = id
    }

    interface  RechargeListen{
        fun onclik02()
    }

    fun setRechargeListen(listener: RechargeListen){
        this.listener =listener
    }





}