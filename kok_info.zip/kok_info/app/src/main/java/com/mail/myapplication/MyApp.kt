package com.mail.myapplication

import cn.jpush.android.api.JPushInterface
import com.mail.comm.app.AppConfig
import com.mail.comm.app.BaseApp

class MyApp : BaseApp() {

    var list_select = ArrayList<MutableMap<String, String>>()

    override fun onCreate() {
        super.onCreate()
        JPushInterface.setDebugMode(AppConfig.debug)
        JPushInterface.init(this)
    }


}