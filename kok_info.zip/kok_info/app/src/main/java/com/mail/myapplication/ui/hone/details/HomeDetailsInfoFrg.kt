package com.mail.myapplication.ui.hone.details

import android.graphics.Color
import android.media.tv.TvView
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.hone.HomeListFrg
import com.mail.myapplication.ui.hone.ImageAdapter
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class HomeDetailsInfoFrg:BaseXFrg() {

    lateinit var mBinding: FrgHomeDetailsIdeaBinding
    lateinit var mAdapter: GoldRecyclerAdapter

    var home = Home()
    lateinit var map_data:MutableMap<String,String>
    lateinit var map_data_user:MutableMap<String,String>

    var list = ArrayList<MutableMap<String, String>>()
    var list_banner = ArrayList<MutableMap<String, String>>()

    override fun getLayoutView(): View {
        mBinding = FrgHomeDetailsIdeaBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getLayoutId() = 0

    override fun initView() {
    }

    override fun requestData() {
        home.a3("video_info","",this)
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "ad/list"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                home.a11(map_data["id"].toString(),this)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list_banner = JSONUtils.parseKeyAndValueToMapList(str)
            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "video/recommend"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list = JSONUtils.parseKeyAndValueToMapList(str)

                var mLayoutManager2 = GridLayoutManager(activity, 1)
                mLayoutManager2.orientation = RecyclerView.VERTICAL
                mBinding.recyclerview.layoutManager = mLayoutManager2
                mAdapter = GoldRecyclerAdapter()
                mBinding.recyclerview.adapter = mAdapter

            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "video/recommend"||type == "ad/list"){
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }
    companion object {

        fun create(json: String): HomeDetailsInfoFrg {
            val fragment = HomeDetailsInfoFrg()
            val bundle = Bundle()
            bundle.putString("json", json)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        with(mBinding) {

            mBinding.loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

            var json = arguments?.getString("json").toString()

             map_data = JSONUtils.parseKeyAndValueToMap(json)
             map_data_user = JSONUtils.parseKeyAndValueToMap(map_data["user"])

//            var maxW =AutoUtils.getPercentWidthSize(200)
//            ImageLoader.loadImageAes(requireActivity()!! ,map_data_user["avatar"],mBinding.imgv,maxW,maxW)


        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            when (viewType) {
                0 -> {
                    return fGoldViewHolderHead(ItemHomeDetailsInfoHeadBinding.inflate(LayoutInflater.from(activity)))
                }
                else -> {
                    return fGoldViewHolder(ItemHomeDetailsInfoBinding.inflate(LayoutInflater.from(activity)))
                }
            }

        }

        override fun getItemCount(): Int = list.size+1

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolderHead) {
                with(holder.mBinding){

                    if (list_banner == null || list_banner.size == 0){
                        relayBanner.visibility = View.GONE
                    }else{
                        relayBanner.visibility = View.VISIBLE

                        banner1.indicator = CircleIndicator(activity)
                        banner1.setBannerGalleryEffect(
                            AutoUtils.getPercentWidthSizeBigger(0),
                            AutoUtils.getPercentWidthSizeBigger(0)
                        )
                        banner1.addBannerLifecycleObserver(activity)
                        banner1.isAutoLoop(true)
                        var adapterImg = ImageAdapter(list_banner,activity!!)
                        banner1.setAdapter(adapterImg)
                    }

                    var maxW = AutoLayoutConifg.getInstance().screenWidth
                    ImageLoader.loadImageAes(requireActivity() ,map_data_user["avatar"],ivHead,maxW,maxW)
                    tvNick.text = map_data_user["nick"]
                    tvTitle.text = map_data["title"]
                    tvInfo.text = map_data_user["fans"]+"粉丝"+map_data_user["videos"]+"个视频"
                    tvDes.text ="原创 · ${map_data["total_play"]}次观看 · ${map_data["created_at"]}发布"

                    if (map_data_user["is_follow"] == "1"){
                        imgvIsFollow.setImageResource(R.drawable.ic_16)
                    }else{
                        imgvIsFollow.setImageResource(R.drawable.ic_101)
                    }

                    if (map_data["is_like"] == "1"){
                        imgvIsLike.setImageResource(R.drawable.ic_8)
                    }else{
                        imgvIsLike.setImageResource(R.drawable.ic_99)
                    }

                    if (map_data["is_collect"] == "1"){
                        imgvIsCollect.setImageResource(R.drawable.ic_10)
                        tvIsCollect.setTextColor(Color.parseColor("#FFD943"))
                    }else{
                        imgvIsCollect.setImageResource(R.drawable.ic_100)
                        tvIsCollect.setTextColor(Color.parseColor("#333333"))
                    }

                    var list_category = JSONUtils.parseKeyAndValueToMapList(map_data["category"])

                    if (list_category == null || list_category.size==0){
                        tvTag1.visibility = View.GONE
                        tvTag2.visibility = View.GONE
                        tvTag3.visibility = View.GONE
                    }else if (list_category.size == 1){
                        tvTag1.visibility = View.VISIBLE
                        tvTag2.visibility = View.GONE
                        tvTag3.visibility = View.GONE
                        tvTag1.text = list_category[0]["name"]
                    }else if (list_category.size == 2){
                        tvTag1.visibility = View.VISIBLE
                        tvTag2.visibility = View.VISIBLE
                        tvTag3.visibility = View.GONE
                        tvTag1.text = list_category[0]["name"]
                        tvTag2.text = list_category[1]["name"]
                    }else{
                        tvTag1.visibility = View.VISIBLE
                        tvTag2.visibility = View.VISIBLE
                        tvTag3.visibility = View.VISIBLE
                        tvTag1.text = list_category[0]["name"]
                        tvTag2.text = list_category[1]["name"]
                        tvTag3.text = list_category[2]["name"]
                    }
                }

            }

            if (holder is fGoldViewHolder){


                holder.itemView.setOnClickListener {
                    startActivity(HomeDetailsAty::class.java)
                }

                with(holder.mBinding){

                    var mPosition = position-1
                    var maxW = AutoLayoutConifg.getInstance().screenWidth/2
                    ImageLoader.loadImageAes(requireActivity() ,map_data_user["avatar"],imgv,maxW,maxW)

                    var map_user_s = JSONUtils.parseKeyAndValueToMap(list[mPosition]["user"])
                    tvTitle.text = list[mPosition]["title"]
                    tvTime.text =   TimeUtils.formatSecond2(list[mPosition]["time"].toString().toDouble())
                    tvDes.text = map_user_s["nick"]+"  "+list[mPosition]["total_play"]+"次观看"

                }


            }
        }

        inner class fGoldViewHolderHead(binding: ItemHomeDetailsInfoHeadBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemHomeDetailsInfoHeadBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

        inner class fGoldViewHolder(binding: ItemHomeDetailsInfoBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemHomeDetailsInfoBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }



}