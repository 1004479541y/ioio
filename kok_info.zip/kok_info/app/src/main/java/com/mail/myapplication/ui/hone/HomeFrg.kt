package com.mail.myapplication.ui.hone

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.comm.base.BaseAty
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgHomeBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.create.CreateTravelAty
import com.mail.myapplication.ui.create.PostImgAty
import com.mail.myapplication.ui.dg.UpdateDialog
import com.mail.myapplication.ui.dg.sort.HomeSortDgFrg
import com.mail.myapplication.ui.hone.search.SearchAty
import java.util.ArrayList

class HomeFrg:BaseXFrg() {

    lateinit var mBinding: FrgHomeBinding

    override fun getLayoutId(): Int = 0

     var list_frg = ArrayList<BaseXFrg>()
     var list_tab = ArrayList<MutableMap<String,String>>()

    var home = Home()

    override fun getLayoutView(): View {
        mBinding = FrgHomeBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a1(this)
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "tag/list"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_name = HashMap<String,String>()
                var map_name2 = HashMap<String,String>()
                var map_name3 = HashMap<String,String>()
                map_name["name"] = "关注"
                map_name["id"] = "gz"
                map_name2["name"] = "推荐"
                map_name2["id"] = "tj"
                map_name3["name"] = "拼多多"
                map_name3["id"] = "pdd"
                list_tab.add(map_name)
                list_tab.add(map_name2)
                list_tab.add(map_name3)

                var m_list_tab = JSONUtils.parseKeyAndValueToMapList(str)
                list_tab.addAll(m_list_tab)

                for ( i in list_tab.indices){
                    list_frg.add(HomeListFrg.create(list_tab[i]["name"].toString(),list_tab[i]["id"].toString()))
                }

                mBinding.vp.setAdapter( MyPagerAdapter(childFragmentManager))
                mBinding.layoutTab.setViewPager(mBinding.vp)
                mBinding.vp.offscreenPageLimit = list_frg.size

            }
        }
    }


    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "tag/list") {
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


        mBinding.relaySearch.setOnClickListener {
            startActivity(SearchAty::class.java)
        }

        mBinding.linlay1.setOnClickListener {
//            startActivity(PostImgAty::class.java)
            startActivity(CreateTravelAty::class.java)
        }

        mBinding.relayRight.setOnClickListener {
//            if (mHomeSortDgFrg == null) {
//                mHomeSortDgFrg = HomeSortDgFrg(activity as BaseAty)
//            }
//            mHomeSortDgFrg?.show()

            var dg = HomeSortDgFrg()
//                startProgressDialog()
//                home.a28("1",map_user["code"]!!,this@HomeListFrg)
            dg.show(childFragmentManager,"HomeSortDgFrg")
        }

        mBinding.loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
            override fun reload() {
                requestData()
            }
        })
    }

    inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
        var mFragmentManager: FragmentManager

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

        override fun getPageTitle(position: Int) = list_tab[position]["name"]

        override fun getItemPosition(`object`: Any) = POSITION_NONE

        init {
            mFragmentManager = fm
        }
    }
}