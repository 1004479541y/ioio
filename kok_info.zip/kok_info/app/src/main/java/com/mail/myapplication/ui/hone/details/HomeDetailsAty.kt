package com.mail.myapplication.ui.hone.details

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultAllocator
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.video.exo.CacheDataSourceFactory
import com.mail.comm.view.load.XLoadTip
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyHomeDetailsBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.dg.CoinsPayDialog
import com.mail.myapplication.ui.dg.ReportDg2Frg
import com.mail.myapplication.ui.dg.ReportDgFrg
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import org.xutils.common.util.LogUtil
import java.util.ArrayList

class HomeDetailsAty:BaseXAty() {

    lateinit var mBinding: AtyHomeDetailsBinding

    var list_frg = ArrayList<BaseXFrg>()
    var reportDgFrg: ReportDgFrg?=null
    var reportDg2Frg: ReportDg2Frg?=null
    var simpleExoPlayer: SimpleExoPlayer? = null

    var id_video =""
    var home = Home()
    var mCoinsPayDialog: CoinsPayDialog?=null


    override fun initView() {
        id_video = intent.getStringExtra("id_video").toString()
    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a10(id_video,this)
    }

    override fun getLayoutView(): View {
        mBinding = AtyHomeDetailsBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onResume() {
        super.onResume()
        simpleExoPlayer?.play()
    }

    override fun onPause() {
        super.onPause()
        simpleExoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        simpleExoPlayer?.release()
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "video/info"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)

                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var map_data =JSONUtils.parseKeyAndValueToMap(str)
                var map_data_auth_error = JSONUtils.parseKeyAndValueToMap(map_data["auth_error"])
                var map_data_user = JSONUtils.parseKeyAndValueToMap(map_data["user"])


//                var maxW = AutoLayoutConifg.getInstance().screenWidth
//                ImageLoader.loadImageAes(this ,map_data["cover"],mBinding.imgvCover,maxW,maxW)

                list_frg.add(HomeDetailsInfoFrg.create(str))
                list_frg.add(HomeDetailsIdeaFrg.create(map_data["id"].toString()))
                mBinding.vp.adapter = MyPagerAdapter(supportFragmentManager)
                mBinding.vp.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
                    override fun onPageScrolled(
                        position: Int,
                        positionOffset: Float,
                        positionOffsetPixels: Int,
                    ) {
                    }

                    override fun onPageSelected(position: Int) {

                        if (position == 0){

                            mBinding.tv01.setTextColor(Color.parseColor("#000000"))
                            mBinding.tv02.setTextColor(Color.parseColor("#7a7a7a"))
                            mBinding.v01.visibility = View.VISIBLE
                            mBinding.v02.visibility = View.INVISIBLE
                        }else{
                            mBinding.tv02.setTextColor(Color.parseColor("#000000"))
                            mBinding.tv01.setTextColor(Color.parseColor("#7a7a7a"))
                            mBinding.v02.visibility = View.VISIBLE
                            mBinding.v01.visibility = View.INVISIBLE
                        }
                    }

                    override fun onPageScrollStateChanged(state: Int) {
                    }

                })

                //可以观看
                if (map_data_auth_error == null){
                    initPlayer(map_data["mu"].toString())
                }else{

                    //错误码 1001=次数已用完，开通VIP享不限次观,1002=金币帖子查看完整版需支付金币,1003=私密帖子仅限粉丝观看
                    when(map_data_auth_error["key"]){

                        "1001"->{
                            mBinding.relayVip.visibility = View.VISIBLE
                         }


                        //金币视频
                        "1002"->{

                            mBinding.relayOrder.visibility = View.VISIBLE
                            mBinding.tvCoins.text = "支付${map_data["coins"]}金币"
                            mBinding.tvCoinsDes.visibility = View.GONE

                            mBinding.relayBottom.visibility = View.VISIBLE
                            mBinding.tvCoins2.text = map_data["coins"]

                         }

                        //私密视频
                         "1003"->{
                             mBinding.relayOrder.visibility = View.VISIBLE
                             mBinding.tvOrderInfo.text = "当前为用户发布的粉丝视频"
                             mBinding.imgvOrder.visibility = View.GONE
                             mBinding.tvCoins.visibility = View.GONE

                         }


                        //私密视频+金币视频
                        "1004"->{

                            mBinding.relayOrder.visibility = View.VISIBLE
                            mBinding.tvCoins.text = "支付${map_data["coins"]}金币"
                            mBinding.tvCoinsDes.visibility = View.VISIBLE

                            mBinding.relayBottom.visibility = View.VISIBLE
                            mBinding.tvCoins2.text = map_data["coins"]

                        }


                    }
                }


            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "video/info") {
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStatusColor("#000000")
        setAndroidNativeLightStatusBar(false)

        mBinding.loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
            override fun reload() {
                requestData()
            }

        })
    }


    fun initPlayer(video: String) {
        var videoTrackSelectionFactory = AdaptiveTrackSelection.Factory()

        //轨道选择器
        var trackSelector = DefaultTrackSelector(this, videoTrackSelectionFactory)

        //用于控制MediaSource何时缓冲更多的媒体资源以及缓冲多少媒体资源
        var loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE))
            .setBufferDurationsMs(360000, 600000, 1000, 5000)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setTargetBufferBytes(C.LENGTH_UNSET)
            .createDefaultLoadControl()

        //Provides estimates of the currently available bandwidth.
        var bandwidthMeter = DefaultBandwidthMeter.Builder(this).build()

        //渲染器，用于渲染媒体文件。
        var renderersFactory = DefaultRenderersFactory(this)

//        val cache: Cache = VideoCache.getInstance()

        simpleExoPlayer = SimpleExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setBandwidthMeter(bandwidthMeter)
            .build()

//        var dataSourceFactory = DefaultDataSourceFactory(requireContext(), Util.getUserAgent(requireContext(), "壹同"))

        var dataSourceCacheFactory = CacheDataSourceFactory(this, 1024 * 1024 * 1024, 5 * 1024 * 1024,"壹同")

        var currUrl = video

        LogUtil.e("currUrl=="+currUrl)

        //播放的媒体文件
        var videoSource: MediaSource
        if (currUrl.contains(".m3u8")) {
            videoSource = HlsMediaSource.Factory(dataSourceCacheFactory)
                .createMediaSource(Uri.parse(currUrl));
            //addEventListener 这里只有两个参数都要传入值才可以成功设置
            // 否者会被断言 Assertions.checkArgument(handler != null && eventListener != null);
            // 并且报错  IllegalArgumentException()  所以不需要添加监听器时 注释掉
            //      videoSource .addEventListener( handler, null);
        } else {
            videoSource = ProgressiveMediaSource.Factory(dataSourceCacheFactory)
                .createMediaSource(Uri.parse(currUrl));
        }

//        var audioSource =  ExtractorMediaSource(Uri.parse(url), CacheDataSourceFactory(context, 100 * 1024 * 1024, 5 * 1024 * 1024),  DefaultExtractorsFactory(), null, null);

        simpleExoPlayer?.addListener(object : Player.EventListener {

            override fun onPlayerError(error: ExoPlaybackException) {
                super.onPlayerError(error)
//                showToastS("播放异常")
            }

            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
//                Log.e("ExoPlayer","playWhenReady: $playWhenReady  +$playbackState")
                when (playbackState) {
//                    Player.STATE_BUFFERING -> {
//                        // showToastS("加载中")
//                        mBinding.downLoading.startAnimation(animation2)
//                        mBinding.linlayLoad.visibility = View.VISIBLE
//                    }
//                    Player.STATE_READY -> {
//                        //showToastS("播放中")
//                        mBinding.downLoading.clearAnimation()
//                        mBinding.linlayLoad.visibility = View.GONE
//                        mBinding.playerView.visibility = View.VISIBLE
//                        mBinding.imgvVideo.visibility = View.GONE
//
//                    }
//                    Player.STATE_ENDED -> {
//                        //showToastS("播放结束")
//                        mBinding.downLoading.clearAnimation()
//                        mBinding.linlayLoad.visibility = View.GONE
//                    }
                }
            }
        })

        simpleExoPlayer?.prepare(videoSource)
        simpleExoPlayer?.playWhenReady = true  //自动播放
        simpleExoPlayer?.repeatMode = Player.REPEAT_MODE_ONE   //循环播放
        mBinding.playerView.player = simpleExoPlayer;

    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.linlay_01 ->{
                mBinding.vp.setCurrentItem(0)

            }

            R.id.linlay_02 ->{
                mBinding.vp.setCurrentItem(1)

            }

            R.id.imgv_back ->{
                finish()
            }

            R.id.imgv_more -> {
                if (reportDgFrg == null) {
                    reportDgFrg = ReportDgFrg(this)
                }
                reportDgFrg?.setRechargeListen(object : ReportDgFrg.RechargeListen {
                    override fun onclik02() {
                        if (reportDg2Frg == null) {
                            reportDg2Frg = ReportDg2Frg(this@HomeDetailsAty)
                        }
                        reportDg2Frg?.show()

                    }
                }
                )
                reportDgFrg?.show()
            }

            R.id.tv_pay ->{

                if (mCoinsPayDialog == null){
                    mCoinsPayDialog = CoinsPayDialog(this)
                }
                mCoinsPayDialog?.setData(mBinding.tvCoins2.text.toString())
                mCoinsPayDialog?.show()
            }
        }
    }
            inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

    }

}