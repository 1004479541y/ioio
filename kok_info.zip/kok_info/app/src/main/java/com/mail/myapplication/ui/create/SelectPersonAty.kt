package com.mail.myapplication.ui.create

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.hone.ImageAdapter
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class SelectPersonAty:BaseXAty() {

    lateinit var mBinding: AtySelectPersonBinding

    var is_fans = "0"

    override fun initView() {
        is_fans =  intent.getStringExtra("is_fans").toString()
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtySelectPersonBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "选择人群"
            include.tvRight.text = "确认"
            include.tvRight.visibility = View.VISIBLE
        }
        a1()
    }

    fun a1(){
        if (is_fans == "1"){
            mBinding.tvName1.setTextColor(Color.parseColor("#FF3434"))
            mBinding.tvName2.setTextColor(Color.parseColor("#FF333438"))

            mBinding.imgv1.visibility = View.VISIBLE
            mBinding.imgv2.visibility = View.GONE
        }else{
            mBinding.tvName2.setTextColor(Color.parseColor("#FF3434"))
            mBinding.tvName1.setTextColor(Color.parseColor("#FF333438"))
            mBinding.imgv1.visibility = View.GONE
            mBinding.imgv2.visibility = View.VISIBLE
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.relay_1 -> {
                is_fans = "1"
                a1()
            }

            R.id.relay_2 -> {
                is_fans = "0"
                a1()
            }

            R.id.tv_right ->{
                var intent = Intent()
                intent.putExtra("is_fans", is_fans)
                setResult(RESULT_OK, intent)
                finish()
            }

        }
    }


}