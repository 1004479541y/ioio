package com.mail.myapplication.ui.mine.opus

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.mail.comm.function.chooseimg.ChooseImgAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.utils.FileSizeUtil
import com.mail.comm.utils.JSONUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.interfaces.Home

class OpusCreateAty : BaseXAty() {

    lateinit var mBinding: AtyOpusCreateBinding
    var position: Int = 0
    var cover_path = ""
    var title = ""
    var home = Home()

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyOpusCreateBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "创建合集"
            include.tvRight.text = "确定"
            include.tvRight.visibility = View.VISIBLE
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

            R.id.imgv -> {
                var bundle = Bundle()
                bundle.putInt("max_num", 1)
                bundle.putString("ratio", "16,9")
                startActivityForResult(ChooseImgAty::class.java, bundle, 300)
            }

            R.id.tv_right->{
                title = mBinding.editTitle.text.toString()
                if (TextUtils.isEmpty(cover_path)){
                    showToastS("请上传合集封面")
                    return
                }
                if (TextUtils.isEmpty(title)){
                    showToastS("请填写合集标题")
                    return
                }
                startProgressDialog()
                home.a5(cover_path,this)

            }

        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)


        if (type == "file/upload") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "0") {
                var dataMap = JSONUtils.parseDataToMap(var2)
                var file_path = dataMap["file_path"]!!
                home.a8(file_path,title,this)

            } else {
                showToastS(map["message"])
            }
        }

        if (type == "album/create") {
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                finish()
            } else {
                showToastS(map["message"])
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        showToastS("网络异常")

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != RESULT_OK) {
            return
        }
        when (requestCode) {

            300 -> {
                var type = data?.getStringExtra("type")

                when (type) {
                    "img_photo" -> {
                        var mlist = data?.getStringArrayListExtra("data")
                        cover_path = mlist!![0]

                        ImageLoader.loadImage(this, cover_path,
                            mBinding.imgv,
                            false)
                    }
                }
            }

        }
    }



}