package com.mail.myapplication.ui.hone.details

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgHomeDetailsInfoBinding
import com.mail.myapplication.databinding.ItemHomeDetailsIdeaBinding
import com.mail.myapplication.databinding.ItemSearchLogBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.hone.search.SearchAty
import com.yhz.adaptivelayout.utils.AutoUtils

class HomeDetailsIdeaFrg:BaseXFrg() {

    lateinit var mBinding: FrgHomeDetailsInfoBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    var home = Home()
    var id = ""
    var page = 1
    var list = ArrayList<MutableMap<String, String>>()


    override fun getLayoutView(): View {
        mBinding = FrgHomeDetailsInfoBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun getLayoutId() = 0

    override fun initView() {
      id = arguments?.getString("id").toString()
    }

    companion object {

        fun create(json: String): HomeDetailsIdeaFrg {
            val fragment = HomeDetailsIdeaFrg()
            val bundle = Bundle()
            bundle.putString("id", json)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun requestData() {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        home.a13(page,id,this)
    }

     fun requestData2() {
        home.a13(page,id,this)
    }


    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "comment/list") {
            with(mBinding) {
                swipeRefreshLayout.finishRefreshing()
                swipeRefreshLayout.finishLoadmore()
                loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var map = JSONUtils.parseKeyAndValueToMap(var2)
                if (map["code"] == "200") {
                    var str = AESCBCCrypt.aesDecrypt(map["data"])
//                    tvTotal.text = map["total"] + "条评论"
                    var mList = JSONUtils.parseKeyAndValueToMapList(str)
                    if (page == 1) {
                        list.clear()
                        list.addAll(mList)
                    } else {
                        list.addAll(mList)
                    }

                    if (page == 1 && mList.size == 0) {
                    } else {
                        mAdapter?.notifyDataSetChanged()
                    }
                } else {
                    if (page == 1) {
                        loading.setLoadingTip(XLoadTip.LoadStatus.error)
                    }
                }
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        startPostponedEnterTransition()
        if (type == "comment/list") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page == 1 && list.size == 0) {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter

            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    page = 1
                    requestData2()
                }

                override fun loadMoreStart() {
                    page++
                    requestData2()
                }

            })

            loading.setLoadingTipXReloadCallback(object : XLoadTip.LoadingTipXReloadCallback {
                override fun reload() {
                    requestData()
                }
            })
        }


    }


    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemHomeDetailsIdeaBinding.inflate(LayoutInflater.from(activity)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        }


        inner class fGoldViewHolder(binding: ItemHomeDetailsIdeaBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemHomeDetailsIdeaBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }


}