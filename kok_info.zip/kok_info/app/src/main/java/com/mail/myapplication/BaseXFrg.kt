package com.mail.myapplication

import com.mail.comm.base.BaseFrg

abstract class BaseXFrg : BaseFrg() {


}



