package com.mail.myapplication.ui.hone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.*
import com.yhz.adaptivelayout.utils.AutoUtils

class CollecHotFrg:BaseXFrg() {

    lateinit var mBinding: FrgCollecHotBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    override fun getLayoutId(): Int = 0


    companion object {

        fun create(type: String): CollecHotFrg {
            val fragment = CollecHotFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun getLayoutView(): View {
        mBinding = FrgCollecHotBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
//                    page=1
//                    requestData2()
                }

                override fun loadMoreStart() {
//                    page++
//                    requestData2()
                }

            })

            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }
            })

        }

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemCollectHotFrgBinding.inflate(LayoutInflater.from(activity)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        }

        inner class fGoldViewHolder(binding: ItemCollectHotFrgBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemCollectHotFrgBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}