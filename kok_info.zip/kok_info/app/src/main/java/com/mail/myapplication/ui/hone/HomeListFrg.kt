package com.mail.myapplication.ui.hone

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.TimeUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.FrgHomeListBinding
import com.mail.myapplication.databinding.ItemHomeListAttenBinding
import com.mail.myapplication.databinding.ItemHomeListBinding
import com.mail.myapplication.databinding.ItemHomeListHeadBinding
import com.mail.myapplication.interfaces.Home
import com.mail.myapplication.ui.dg.sort.HomeSortListFrg
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.mail.myapplication.ui.mine.fans.FansGroupAty
import com.mail.myapplication.ui.page.OtherPageAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeListFrg:BaseXFrg() {

    lateinit var mBinding: FrgHomeListBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    var type =""
    var id =""
    var home = Home()
    var page = 1
    var list = ArrayList<MutableMap<String, String>>()
    var list_banner = ArrayList<MutableMap<String, String>>()


    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = FrgHomeListBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
        type = arguments?.getString("type").toString()
        id =arguments?.getString("id","").toString()
    }

    override fun requestData( ) {
        mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.loading)
        requestDataBanner()
    }

    fun requestDataBanner(){
        when(type){

            "关注"->{
                home.a3("home_recommend","",this)
            }

            "推荐"->{
                home.a3("home_recommend","",this)
            }

            "拼多多" ->{
                home.a3("ping","",this)
            }

            else ->{
                home.a3("home_categroy",id,this)
            }
        }
    }

    fun requestDataList(){
        when(type){

            "推荐"->{
                home.a2(page,this)
            }

            "关注"->{
                home.a15(page,this)
            }

            "拼多多"->{

            }

            else ->{
                home.a14(page,id,this)
            }

        }
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)

        if (type == "ad/list"){
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                list_banner = JSONUtils.parseKeyAndValueToMapList(str)
                requestDataList()

            }else{
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            }
        }

        if (type == "home/list") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
                var str = AESCBCCrypt.aesDecrypt(map["data"])
                var mList = JSONUtils.parseKeyAndValueToMapList(str)
                var index1 = list.size+1
                if (page == 1) {
                    list.clear()
                    list.addAll(mList)
                } else {
                    list.addAll(mList)
                }
                if (page == 1 && mList.size == 0) {
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.empty)
                } else {
                    if (mList != null && mList.size > 0) {

                        if (page == 1) {
                            mAdapter.notifyDataSetChanged()
                            mBinding.recyclerview.scrollToPosition(0)
                        } else {
                            mAdapter.notifyItemRangeInserted(index1, list.size)
                        }
                    }
                }

            } else {
                if (page == 1) {
                    mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
                }
            }
            mBinding.swipeRefreshLayout.finishRefreshing()

        }

    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        stopProgressDialog()
        if (type == "home/list") {
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            if (page == 1 && list.size == 0) {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
            } else {
                mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.finish)
            }
        }

        if (type == "ad/list"){
            mBinding.swipeRefreshLayout.finishRefreshing()
            mBinding.swipeRefreshLayout.finishLoadmore()
            mBinding.loading.setLoadingTip(XLoadTip.LoadStatus.error)
        }
    }

    companion object {

        fun create(type: String,id:String): HomeListFrg {
            val fragment = HomeListFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            bundle.putString("id", id)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        with(mBinding){
//            banner1.indicator = CircleIndicator(activity)
//            banner1.setBannerGalleryEffect(
//                AutoUtils.getPercentWidthSizeBigger(0),
//                AutoUtils.getPercentWidthSizeBigger(0)
//            )
//            banner1.addBannerLifecycleObserver(activity)
//            banner1.isAutoLoop(true)
//
//            var list_banner = ArrayList<MutableMap<String,String>>()
//            list_banner.add(HashMap<String,String>())
//            var adapterImg = ImageAdapter(list_banner)
//            banner1.setAdapter(adapterImg)
        }

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                    page=1
                    requestDataBanner()
                }

                override fun loadMoreStart() {
                    page++
                    requestDataBanner()
                }

            })
            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }

            })

        }

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            when (viewType) {

                0 -> {
                    return fGoldViewHolderHead(ItemHomeListHeadBinding.inflate(LayoutInflater.from(activity)))
                }

                else -> {
                    return fGoldViewHolder(ItemHomeListBinding.inflate(LayoutInflater.from(activity)))
                }
            }

        }

        override fun getItemCount(): Int = list.size+1

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolderHead) {

                with(holder.mBinding) {
                    if (list_banner == null || list_banner.size == 0){
                        relayBanner.visibility = View.GONE
                    }else{
                        relayBanner.visibility = View.VISIBLE

                        banner1.indicator = CircleIndicator(activity)
                        banner1.setBannerGalleryEffect(
                            AutoUtils.getPercentWidthSizeBigger(0),
                            AutoUtils.getPercentWidthSizeBigger(0)
                        )
                        banner1.addBannerLifecycleObserver(activity)
                        banner1.isAutoLoop(true)
                        var adapterImg = ImageAdapter(list_banner,activity!!)
                        banner1.setAdapter(adapterImg)
                    }

                    relayHj.setOnClickListener {
                        startActivity(CollecHotAty::class.java)
                    }

                    relayFansGroup.setOnClickListener {
                        startActivity(FansGroupAty::class.java)
                    }


                    if (this@HomeListFrg.type == "关注"){
                        recyclerview.visibility = View.VISIBLE
                        var mLayoutManager2 = LinearLayoutManager(activity)
                        mLayoutManager2.orientation = RecyclerView.HORIZONTAL
                        recyclerview.layoutManager = mLayoutManager2
                        var mAdapter = AttenGoldRecyclerAdapter()
                        recyclerview.adapter = mAdapter
                    }else{
                        recyclerview.visibility = View.GONE
                    }
                }

            }

            if (holder is fGoldViewHolder){

                with(holder){
                    var mPosition = position-1

                    var map_user = JSONUtils.parseKeyAndValueToMap(list[mPosition]["user"])

                    holder.itemView.setOnClickListener {
                        var bundle = Bundle()
                        bundle.putString("id_video",list[mPosition]["id"])
                        startActivity(HomeDetailsAty::class.java,bundle)
                    }
//http://cdnimg.ty.tkqhqty.cn/ig/user/081019/9138e73eacb5f9f5.ceb
                    var maxW = AutoLayoutConifg.getInstance().screenWidth
                    ImageLoader.loadImageAes(context!! ,list[mPosition]["cover"],mBinding.imgv,maxW,maxW)

                    var maxW2 = AutoUtils.getPercentWidthSize(200)
                    ImageLoader.loadImageAes(context!! ,map_user["avatar"],mBinding.ivHead,maxW2,maxW2)
                    mBinding.tvNick.text = map_user["nick"]

                    if (map_user["is_follow"] == "1"){
                        mBinding.tvIsFollow.text ="已关注"
                        mBinding.tvIsFollow.setTextColor(Color.parseColor("#FFA4A4A4"))

                    }else{
                        mBinding.tvIsFollow.text ="关注"
                        mBinding.tvIsFollow.setTextColor(Color.parseColor("#FFFF3434"))
                    }

                    if (map_user["is_creator"] == "1"){
                        mBinding.tvIsCreate.text = "官方认证达人"
                        mBinding.tvIsCreate.visibility = View.VISIBLE
                    }else{
                        mBinding.tvIsCreate.visibility = View.GONE
                    }

                    if (list[mPosition]["is_like"] == "1"){
                        mBinding.imgvIsLike.setImageResource(R.drawable.ic_8)
                    }else{
                        mBinding.imgvIsLike.setImageResource(R.drawable.ic_99)
                    }

                    if (list[mPosition]["total_like"] == "0"){
                        mBinding.tvIsLike.visibility = View.GONE
                    }else{
                        mBinding.tvIsLike.visibility = View.VISIBLE
                        mBinding.tvIsLike.text = list[mPosition]["total_like"]
                    }

                    if (list[mPosition]["is_collect"] == "1"){
                        mBinding.imgvIsCollect.setImageResource(R.drawable.ic_10)
                    }else{
                        mBinding.imgvIsCollect.setImageResource(R.drawable.ic_100)
                    }

                    if (list[mPosition]["total_collect"] == "0"){
                        mBinding.tvComment.visibility = View.GONE
                    }else{
                        mBinding.tvComment.visibility = View.VISIBLE
                        mBinding.tvComment.text = list[mPosition]["total_collect"]
                    }

                    if (list[mPosition]["total_comment"] == "0"){
                        mBinding.tvComment.visibility = View.GONE
                    }else{
                        mBinding.tvComment.visibility = View.VISIBLE
                        mBinding.tvComment.text = list[mPosition]["total_comment"]
                    }

                    if (list[mPosition]["total_share"] == "0"){
                        mBinding.tvShare.visibility = View.GONE
                    }else{
                        mBinding.tvShare.visibility = View.VISIBLE
                        mBinding.tvShare.text = list[mPosition]["total_share"]
                    }


                }

            }
        }

        inner class fGoldViewHolderHead(binding: ItemHomeListHeadBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemHomeListHeadBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

        inner class fGoldViewHolder(binding: ItemHomeListBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemHomeListBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

        inner class AttenGoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                return fGoldViewHolder(ItemHomeListAttenBinding.inflate(LayoutInflater.from(context)))
            }

            override fun getItemCount(): Int = 5


            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

                if (holder is fGoldViewHolder) {

                    holder.itemView.setOnClickListener {

                        startActivity(OtherPageAty::class.java)
                    }

                }
            }

            inner class fGoldViewHolder(binding: ItemHomeListAttenBinding) : RecyclerView.ViewHolder(binding.root) {
                var mBinding: ItemHomeListAttenBinding = binding
                init {
                    AutoUtils.autoSize(binding.root)
                }
            }


        }


    }

}