package com.mail.myapplication.ui.create

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.comm.function.choosevideo.ChooseVideoAty
import com.mail.comm.utils.FileSizeUtil
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgCreateBinding
import com.mail.myapplication.databinding.FrgHomeBinding
import com.mail.myapplication.ui.hone.search.SearchAty
import com.yhz.adaptivelayout.AdaptiveLayoutActivity
import org.xutils.common.util.LogUtil
import java.util.ArrayList

class CreateFrg:BaseXFrg() {

    lateinit var mBinding: FrgCreateBinding

    override fun getLayoutId(): Int = 0

     var list_frg = ArrayList<BaseXFrg>()
     var list_tab = ArrayList<String>()

    override fun getLayoutView(): View {
        mBinding = FrgCreateBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


        with(mBinding){
            linlayUpload.setOnClickListener {
                var bundle = Bundle()
                startActivityForResult(ChooseVideoAty::class.java, bundle, 400)
            }

            linlayPostImg.setOnClickListener {
                startActivity(PostImgAty::class.java)
            }
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != AdaptiveLayoutActivity.RESULT_OK) {

            return
        }
        when (requestCode) {

            400 -> {

                var path = data?.getStringExtra("data")
                var size = FileSizeUtil.getFileOrFilesSize(path, FileSizeUtil.SIZETYPE_MB)
//                showToastS(path)
                startActivity(PostVideoAty::class.java)

            }
        }
    }

}