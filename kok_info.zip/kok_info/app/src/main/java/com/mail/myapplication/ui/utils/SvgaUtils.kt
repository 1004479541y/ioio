package com.mail.myapplication.ui.utils

import androidx.lifecycle.lifecycleScope
import com.mail.myapplication.BaseXAty
import com.opensource.svgaplayer.SVGAImageView
import com.opensource.svgaplayer.SVGAParser
import com.opensource.svgaplayer.SVGAVideoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.xutils.common.util.LogUtil
import org.xutils.x
import java.net.URL
import java.util.*

class SvgaUtils {
    var list = ArrayList<HashMap<String, String>>()
    var isPlay = false
    var mSvgUtilsListen: SvgUtilsListen?=null
    var isLoop = true
    init {
        isLoop = true
    }


    fun setIsPlay(isPlay: Boolean) {
        this.isPlay = isPlay
    }

    fun addAnimation(map: HashMap<String, String>) {
        list.add(map)
    }

    fun loopAnimation(mContext: BaseXAty, mSVGAImage: SVGAImageView) {

        mContext.lifecycleScope.launch(Dispatchers.IO) {

            while (true&&isLoop) {
//                LogUtil.e("lifecycleScope3 ===="+list.size)
                if (!isPlay && list.size > 0) {
                    LogUtil.e("lifecycleScope4 ===="+list.size)
                    isPlay = true
                    load(list[0], mSVGAImage)
                    if (list[0].containsKey("msg")){
                        mSvgUtilsListen?.receiveGift(list[0]["msg"])
                    }
                    list.removeAt(0)

                }
            }
        }
    }

    interface SvgUtilsListen {
        fun receiveGift(msg:String?)
    }

    fun setSvgUtilsListen(mSvgUtilsListen: SvgUtilsListen){
        this.mSvgUtilsListen = mSvgUtilsListen;
    }

    fun onDestroy(){
        isLoop = false
        this.mSvgUtilsListen =null
    }

    fun load(map: HashMap<String, String>, mSVGAImage: SVGAImageView) {

//        SVGAParser(x.app()).decodeFromURL(map["type"]!!, object : SVGAParser.ParseCompletion {
//            @RequiresApi(api = Build.VERSION_CODES.P)
//            override fun onComplete(videoItem: SVGAVideoEntity) {
//                if (mSVGAImage != null) {
//                    mSVGAImage?.setVideoItem(videoItem)
//                    mSVGAImage?.stepToFrame(0, true)
//                }
//            }
//
//            override fun onError() {}
//        })
        var url = URL(map["url_svga"])
        SVGAParser(x.app()).decodeFromURL(url,object : SVGAParser.ParseCompletion{
            override fun onComplete(videoItem: SVGAVideoEntity) {
                if (mSVGAImage != null) {
                    mSVGAImage?.setVideoItem(videoItem)
                    mSVGAImage?.stepToFrame(0, true)
                }
            }

            override fun onError() {
            }

        })

//        parser.decodeFromURL(new URL("https://github.com/yyued/SVGA-Samples/blob/master/posche.svga?raw=true"), new SVGAParser.ParseCompletion() {
//            // ...
//        }, object : SVGAParser.PlayCallback {
//            // The default is null, can not be set
//        })
    }

}