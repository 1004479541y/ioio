package com.mail.myapplication.ui.video

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgHomeBinding
import com.mail.myapplication.databinding.FrgVideoBinding
import com.mail.myapplication.ui.hone.search.SearchAty
import java.util.ArrayList

class VideoFrg:BaseXFrg() {

    lateinit var mBinding: FrgVideoBinding

    override fun getLayoutId(): Int = 0

     var list_frg = ArrayList<BaseXFrg>()
     var list_tab = ArrayList<String>()

    override fun getLayoutView(): View {
        mBinding = FrgVideoBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list_frg.add(VideoListFrg())
        list_frg.add(VideoListFrg())
        list_frg.add(VideoListFrg())
        list_frg.add(VideoListFrg())
        list_frg.add(VideoListFrg())
        list_frg.add(VideoListFrg())
        list_tab.add("关注")
        list_tab.add("推荐")
        list_tab.add("原创")
        list_tab.add("国产")
        list_tab.add("免费")
        list_tab.add("日韩")

        mBinding.vp.setAdapter( MyPagerAdapter(getChildFragmentManager()))
        mBinding.layoutTab.setViewPager(mBinding.vp)
        mBinding.vp.setOffscreenPageLimit(list_frg.size)

        mBinding.relaySearch.setOnClickListener {
            startActivity(SearchAty::class.java)
        }
    }

    inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
        var mFragmentManager: FragmentManager

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

        override fun getPageTitle(position: Int) = list_tab[position]

        override fun getItemPosition(`object`: Any) = POSITION_NONE

        init {
            mFragmentManager = fm
        }
    }
}