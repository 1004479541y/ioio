package com.mail.myapplication.ui.mine.fans

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyFansGroupBinding
import com.mail.myapplication.databinding.AtyFansGroupDetailsBinding
import com.mail.myapplication.databinding.ItemFansGroupBinding
import com.mail.myapplication.databinding.ItemFansGroupDetailsBinding
import com.yhz.adaptivelayout.utils.AutoUtils

class FansGroupAty : BaseXAty() {

    lateinit var mBinding: AtyFansGroupBinding

    var mAdapter: GoldRecyclerAdapter? = null

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = AtyFansGroupBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        setAndroidNativeLightStatusBar(true)


        var mLayoutManager2 = GridLayoutManager(this, 1)
        mLayoutManager2.orientation = RecyclerView.VERTICAL
        mBinding.recyclerview.layoutManager = mLayoutManager2
        mAdapter = GoldRecyclerAdapter()
        mBinding.recyclerview.adapter = mAdapter

        with(mBinding){


        }

    }


    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_back -> {
                finish()
            }

        }
    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemFansGroupBinding.inflate(LayoutInflater.from(this@FansGroupAty)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder) {

                with(holder) {

                    when(position){

                        0 ->{

                        }
                    }
                }

            }

        }

        inner class fGoldViewHolder(binding: ItemFansGroupBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemFansGroupBinding = binding

            init {
                AutoUtils.autoSize(binding.root)
            }
        }

    }


}