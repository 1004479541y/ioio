package com.mail.myapplication.ui.video

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class VideoListFrg:BaseXFrg() {

    lateinit var mBinding: FrgVideoListBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = FrgVideoListBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 2)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
                }

                override fun loadMoreStart() {
                }

            })
            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }

            })

        }

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemVideoBinding.inflate(LayoutInflater.from(activity)))

        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {


            holder.itemView.setOnClickListener {

                startActivity(PlayListAty::class.java)
            }
        }



        inner class fGoldViewHolder(binding: ItemVideoBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemVideoBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}