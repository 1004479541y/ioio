package com.mail.myapplication.ui.create

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.utils.JSONUtils
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.MyApp
import com.mail.myapplication.R
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import java.util.ArrayList

class SelectTagFrg:BaseXFrg() {

    lateinit var mBinding: FrgSelectTabBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    var list = ArrayList<MutableMap<String,String>>()

    var mMyApp : MyApp?=null

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = FrgSelectTabBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
       var str = arguments?.getString("type").toString()
        list = JSONUtils.parseKeyAndValueToMapList(str)
        mMyApp = requireActivity().application as MyApp?

    }

    override fun requestData() {
    }

    companion object {

        fun create(type: String): SelectTagFrg {
            val fragment = SelectTagFrg()
            val bundle = Bundle()
            bundle.putString("type", type)
            fragment.arguments = bundle
            return fragment
        }

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 4)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter

        }

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemSelectTabBinding.inflate(LayoutInflater.from(activity)))

        }

        override fun getItemCount(): Int = list.size

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            if (holder is fGoldViewHolder){


                with(holder){

                    if ( mMyApp!!.list_select.contains(list[position])){
                        mBinding.tvName.setBackgroundResource(R.drawable.ic_90)
                        mBinding.tvName.setTextColor(Color.parseColor("#FF3434"))
                    }else{
                        mBinding.tvName.setBackgroundResource(R.drawable.shape_42)
                        mBinding.tvName.setTextColor(Color.parseColor("#333333"))

                    }

                    mBinding.tvName.text = list[position]["name"]

                    mBinding.tvName.setOnClickListener {


                        if ( mMyApp!!.list_select.contains(list[position])){
                            mMyApp!!.list_select.remove(list[position])
                            notifyItemChanged(position)
                        }else{
                            if ( mMyApp!!.list_select.size>=3){
                                showToastS("最多设置3个标签")
                                return@setOnClickListener
                            }
                            mMyApp!!.list_select.add(list[position])
                            notifyItemChanged(position)
                        }
                    }

                }

            }

        }

        inner class fGoldViewHolder(binding: ItemSelectTabBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemSelectTabBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }

    }

}