package com.mail.myapplication

import android.graphics.Color
import android.widget.RelativeLayout
import com.mail.comm.base.BaseAty
import com.mail.comm.utils.PreferencesUtils
import com.mail.myapplication.interfaces.Home
import com.yhz.adaptivelayout.utils.AutoUtils

abstract  class BaseXAty :BaseAty() {

    var home_baee: Home?=null

    fun requestAdCount(id:String){
        if (home_baee == null){
            home_baee = Home()
        }
        home_baee?.a64(id,this)
    }

    fun setLoginStatus(isLogin:Boolean){
        PreferencesUtils.putBoolean(this,"isLogin",isLogin)
    }

    fun isLogin():Boolean{
        var isLogin = PreferencesUtils.getBoolean(this,"isLogin",false)
        return isLogin
    }

    fun initTopview2(relay: RelativeLayout?, bgColor: String = "#ffffff") {
        val lp = relay?.layoutParams as RelativeLayout.LayoutParams
        lp.height = AutoUtils.getPercentHeightSize(150)
        relay.layoutParams = lp
        relay.setBackgroundColor(Color.parseColor(bgColor))
    }


}