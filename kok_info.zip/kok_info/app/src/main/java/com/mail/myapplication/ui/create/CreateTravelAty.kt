package com.mail.myapplication.ui.create

import android.os.Bundle
import android.view.View
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyCreateTravelBinding

class CreateTravelAty:BaseXAty() {

    lateinit var mBinding: AtyCreateTravelBinding

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtyCreateTravelBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        setAndroidNativeLightStatusBar(false)
    }

    fun mainClick(v: View) {


        when (v.id) {

            R.id.relay_video_long -> {
                var bundle = Bundle()
                bundle.putString("type","long_video")
                startActivity(PostVideoAty::class.java,bundle)
            }

            R.id.relay_video_short -> {
                var bundle = Bundle()
                bundle.putString("type","short_video")
                startActivity(PostVideoAty::class.java,bundle)
            }

            R.id.relay_page -> {
                startActivity(PostImgAty::class.java)
            }

            R.id.relay_page2 -> {
            }

            R.id.relay_back -> {
                finish()
            }
        }
    }

}