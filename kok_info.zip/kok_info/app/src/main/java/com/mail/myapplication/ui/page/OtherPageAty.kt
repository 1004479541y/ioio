package com.mail.myapplication.ui.page

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.AppBarLayout
import com.mail.comm.utils.MyUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyCreateTravelBinding
import com.mail.myapplication.databinding.AtyOtherPageBinding
import com.mail.myapplication.ui.hone.HomeListFrg
import com.mail.myapplication.ui.mine.fans.FansGroupDetailsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import java.lang.Math.abs

class OtherPageAty:BaseXAty() {

    lateinit var mBinding: AtyOtherPageBinding

    lateinit var list_tv: Array<TextView>
    lateinit var list_v: Array<View>

    var list_frg =  ArrayList<BaseXFrg>()

    override fun initView() {
        with(mBinding){
            list_tv = arrayOf(tv01,tv02, tv03,tv04)
            list_v = arrayOf(v01,v02, v03,v04)
        }
    }

    override fun requestData() {}

    override fun getLayoutView(): View {
        mBinding = AtyOtherPageBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTranslanteBar()
        setAndroidNativeLightStatusBar(true)

        with(mBinding){
            linlay001.setOnClickListener {
                viewPager.setCurrentItem(0,true)
            }
            linlay02.setOnClickListener {
                viewPager.setCurrentItem(1,true)

            }
            linlay03.setOnClickListener {
                viewPager.setCurrentItem(2,true)
            }

            linlay04.setOnClickListener {
                viewPager.setCurrentItem(3,true)
            }

            list_frg.add(OtherPageFrg())
            list_frg.add(OtherPageFrg())
            list_frg.add(OtherPageFrg())
            list_frg.add(OtherPageFrg())

            viewPager.adapter = HomeListAdataper(supportFragmentManager, lifecycle, list_frg)

            viewPager.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    when(position){
                        0 -> {
                            setSelector(tv01)
                        }
                        1 -> {
                            setSelector(tv02)
                        }
                        2 -> {
                            setSelector(tv03)
                        }
                        3 -> {
                            setSelector(tv04)
                        }
                    }
                }
            })

            viewPager.setCurrentItem(0,false)


            appbar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { appBarLayout, verticalOffset ->
                val Offset = abs(verticalOffset).toFloat()
                val totalScrollRange = appBarLayout?.totalScrollRange
                var a = (Offset / totalScrollRange!!)
                linlayName.alpha = a
                relayBack.alpha = a
            })
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.imgv_back -> {
                finish()
            }

            R.id.relay_fans_group -> {
                startActivity(FansGroupDetailsAty::class.java)
            }
        }
    }

    inner class HomeListAdataper(fa: FragmentManager, lifecycle: Lifecycle, val list: ArrayList<BaseXFrg>) :

        FragmentStateAdapter(fa, lifecycle) {

        override fun getItemCount(): Int =list.size

        override fun createFragment(position: Int): Fragment = list[position]

    }

    private fun setSelector(tv: TextView) {
        for (i in list_tv.indices) {
            if (tv === list_tv[i]) {
                list_tv[i].setTextColor(Color.parseColor("#000000"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));//加粗


                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(55).toFloat())
                list_v[i].visibility = View.VISIBLE
            } else {
                list_tv[i].setTextColor(Color.parseColor("#999999"))
                list_tv[i].setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));//加粗
                list_tv[i].setTextSize(TypedValue.COMPLEX_UNIT_PX, AutoUtils.getPercentWidthSizeBigger(45).toFloat())
                list_v[i].visibility = View.INVISIBLE
            }
        }
    }

}