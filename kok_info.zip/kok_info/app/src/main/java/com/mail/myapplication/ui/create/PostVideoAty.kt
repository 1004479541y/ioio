package com.mail.myapplication.ui.create

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.mail.comm.function.chooseimg.ChooseImgAty
import com.mail.comm.function.choosevideo.ChooseVideoAty
import com.mail.comm.image.ImageLoader
import com.mail.comm.utils.FileSizeUtil
import com.mail.comm.utils.JSONUtils
import com.mail.myapplication.BaseXAty
import com.mail.myapplication.R
import com.mail.myapplication.databinding.AtyMainBinding
import com.mail.myapplication.databinding.AtyPostVideoBinding
import com.mail.myapplication.interfaces.Home

class PostVideoAty:BaseXAty() {

    lateinit var mBinding: AtyPostVideoBinding

    var upload_max_limit =200

    var type = ""
    var cover_path = ""
    var title = ""
    var is_fans = "0"
    var file_path = ""
    var coins = ""
    var type_ids = ""
    var album_id = ""
    var video_type = ""
    var home = Home()

    var cover_path_net = ""
    var file_path_net = ""

    override fun initView() {
        type = intent.getStringExtra("type").toString()
    }

    override fun requestData() {
    }

    override fun getLayoutView(): View {
        mBinding = AtyPostVideoBinding.inflate(layoutInflater)
        return mBinding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(mBinding){
            initTopview2(include.relayTopBg,"#ffffff")
            include.tvTitle.text = "发布视频"
            setSelectType()
        }
    }

    fun mainClick(v: View) {

        when (v.id) {

            R.id.relay_select_collec -> {
                startActivityForResult(SelectCollecAty::class.java,401)
            }
            R.id.relay_select_person -> {
                var bundle = Bundle()
                bundle.putString("is_fans",is_fans)
                startActivityForResult(SelectPersonAty::class.java,bundle,403)
            }
            R.id.relay_select_tab -> {
                startActivityForResult(SelectTagAty::class.java,402)
            }
            R.id.relay_back -> {
                finish()
            }

            R.id.relay_video ->{
                var bundle = Bundle()
                startActivityForResult(ChooseVideoAty::class.java, bundle, 400)
            }

            R.id.tv_img ->{
                var bundle = Bundle()
                bundle.putInt("max_num", 1)
                bundle.putString("ratio", "16,9")
                startActivityForResult(ChooseImgAty::class.java, bundle, 300)
            }

            R.id.tv_video_long ->{
                type = "long_video"
                setSelectType()
            }

            R.id.tv_video_short ->{
                type = "short_video"
                setSelectType()
            }

            R.id.tv_send ->{

                if (type =="short_video" ){
                    video_type = "1"
                }else{
                    video_type = "2"
                }

                title = mBinding.editTitle.text.toString()
                coins = mBinding.editCoins.text.toString()
                if (TextUtils.isEmpty(title)){
                    showToastS("请填写标题")
                    return
                }

                if (TextUtils.isEmpty(cover_path)){
                    showToastS("请上传封面")
                    return
                }
                if (TextUtils.isEmpty(file_path)){
                    showToastS("请上传视频")
                    return
                }
                if (TextUtils.isEmpty(type_ids)){
                    showToastS("请选择标签")
                    return
                }

                startProgressDialog()
                home?.a5(cover_path,this)

            }
        }
    }

    fun setSelectType(){
        with(mBinding){
            if (type == "long_video"){
                tvVideoLong.setBackgroundResource( R.drawable.shape_8)
                tvVideoLong.setTextColor(Color.parseColor("#ffffff"))
                tvVideoShort.setBackgroundResource( R.drawable.shape_9)
                tvVideoShort.setTextColor(Color.parseColor("#FF3434"))
            }else{
                tvVideoLong.setBackgroundResource( R.drawable.shape_45)
                tvVideoLong.setTextColor(Color.parseColor("#FF3434"))
                tvVideoShort.setBackgroundResource( R.drawable.shape_44)
                tvVideoShort.setTextColor(Color.parseColor("#ffffff"))
            }
        }

    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        if (type == "file/upload") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "0") {
                var dataMap = JSONUtils.parseDataToMap(var2)
                cover_path_net = dataMap["file_path"]!!
                startProgressDialog()
                home.a9(file_path,this)

            } else {
                showToastS(map["message"])
            }
        }
        if (type == "file/upload2") {
            stopProgressDialog()

            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "0") {
                var dataMap = JSONUtils.parseDataToMap(var2)
                file_path_net = dataMap["file_path"]!!
                startProgressDialog()
                home.a4(title,cover_path_net,is_fans,file_path_net,coins,type_ids,album_id,video_type,this)
            } else {
                showToastS(map["message"])
            }
        }

        if (type == "video/create") {
            stopProgressDialog()
            var map = JSONUtils.parseKeyAndValueToMap(var2)
            if (map["code"] == "200") {
                finish()
            } else {
                showToastS(map["message"])
            }
        }
    }

    override fun onExceptionType(type: String?) {
        super.onExceptionType(type)
        if (type == "file/upload"||type == "file/upload2"){
            stopProgressDialog()
            showToastS("网络异常")
        }
        if (type == "video/create"){
            stopProgressDialog()
            showToastS("网络异常")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode != RESULT_OK) {
            return
        }
        when (requestCode) {

            300 -> {
                var type = data?.getStringExtra("type")

                when (type) {
                    "img_photo" -> {
                        var mlist = data?.getStringArrayListExtra("data")
                        cover_path = mlist!![0]

                        ImageLoader.loadImage(this, cover_path,
                            mBinding.imgVideo,
                            false)
                    }
                }
            }

            400 -> {

                file_path= data?.getStringExtra("data").toString()
                var size = FileSizeUtil.getFileOrFilesSize(file_path, FileSizeUtil.SIZETYPE_MB)

                if (size >= upload_max_limit) {
                    showToastS("视频不能大于${upload_max_limit}M")
                    return
                }
                cover_path = ""

                ImageLoader.loadImage(this, file_path,
                    mBinding.imgVideo,
                    false)

            }

            401 -> {

                var album_name = data?.getStringExtra("album_name")
                album_id = data?.getStringExtra("id").toString()
                mBinding.tvAlbumTitle.text = album_name


            }

            402 -> {

                var tag_name = data?.getStringArrayListExtra("tag_name")
                var tag_id = data?.getStringArrayListExtra("tag_id")

                var string = StringBuffer()
                var string2 = StringBuffer()
                for (i in tag_name!!.indices){
                    string.append("#"+tag_name!![i]+"  ")

                    if (i != tag_id!!.size -1){
                        string2.append(tag_id!![i]+",")
                    }else{
                        string2.append(tag_id!![i])
                    }
                }

                mBinding.tvTag.text = string.toString()
                type_ids = string2.toString()
            }

            403 -> {

                is_fans = data?.getStringExtra("is_fans").toString()
                if (is_fans == "1"){
                    mBinding.tvIsFans.text = "仅粉丝"
                }else{
                    mBinding.tvIsFans.text = "所有人"
                }

            }
        }
    }


}