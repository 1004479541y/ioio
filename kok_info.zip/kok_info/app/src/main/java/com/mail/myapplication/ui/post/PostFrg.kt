package com.mail.myapplication.ui.post

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.FrgHomeBinding
import com.mail.myapplication.databinding.FrgPostBinding
import com.mail.myapplication.databinding.FrgVideoBinding
import com.mail.myapplication.ui.hone.search.SearchAty
import java.util.ArrayList

class PostFrg:BaseXFrg() {

    lateinit var mBinding: FrgPostBinding

    override fun getLayoutId(): Int = 0

     var list_frg = ArrayList<BaseXFrg>()
     var list_tab = ArrayList<String>()

    override fun getLayoutView(): View {
        mBinding = FrgPostBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list_frg.add(PostListFrg())
        list_frg.add(PostListFrg())
        list_frg.add(PostListFrg())
        list_frg.add(PostListFrg())
        list_tab.add("关注")
        list_tab.add("广场")
        list_tab.add("最热")
        list_tab.add("最新")

        mBinding.vp.setAdapter( MyPagerAdapter(getChildFragmentManager()))
        mBinding.layoutTab.setViewPager(mBinding.vp)
        mBinding.vp.setOffscreenPageLimit(list_frg.size)

    }

    inner class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
        var mFragmentManager: FragmentManager

        override fun getCount() = list_frg.size

        override fun getItem(position: Int) = list_frg[position]

        override fun getPageTitle(position: Int) = list_tab[position]

        override fun getItemPosition(`object`: Any) = POSITION_NONE

        init {
            mFragmentManager = fm
        }
    }
}