package com.mail.myapplication.ui.page

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mail.comm.image.ImageLoader
import com.mail.comm.view.load.XLoadTip
import com.mail.comm.view.refresh.XRefreshInterface
import com.mail.myapplication.BaseXFrg
import com.mail.myapplication.databinding.*
import com.mail.myapplication.ui.hone.details.HomeDetailsAty
import com.mail.myapplication.ui.page.OtherPageAty
import com.mail.myapplication.ui.utils.MyUtils3
import com.yhz.adaptivelayout.utils.AutoUtils
import com.youth.banner.indicator.CircleIndicator

class OtherPageFrg:BaseXFrg() {

    lateinit var mBinding: FrgOtherPageBinding

    lateinit var mAdapter: GoldRecyclerAdapter

    override fun getLayoutId(): Int = 0

    override fun getLayoutView(): View {
        mBinding = FrgOtherPageBinding.inflate(layoutInflater);
        return mBinding.root
    }

    override fun initView() {
    }

    override fun requestData() {
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        with(mBinding){
//            banner1.indicator = CircleIndicator(activity)
//            banner1.setBannerGalleryEffect(
//                AutoUtils.getPercentWidthSizeBigger(0),
//                AutoUtils.getPercentWidthSizeBigger(0)
//            )
//            banner1.addBannerLifecycleObserver(activity)
//            banner1.isAutoLoop(true)
//
//            var list_banner = ArrayList<MutableMap<String,String>>()
//            list_banner.add(HashMap<String,String>())
//            var adapterImg = ImageAdapter(list_banner)
//            banner1.setAdapter(adapterImg)
        }

        with(mBinding) {
            var mLayoutManager2 = GridLayoutManager(activity, 1)
            mLayoutManager2.orientation = RecyclerView.VERTICAL
            recyclerview.layoutManager = mLayoutManager2
            mAdapter = GoldRecyclerAdapter()
            recyclerview.adapter = mAdapter
            swipeRefreshLayout.setEnableLoadmore(true)
            swipeRefreshLayout.setEnableRefresh(true)
            swipeRefreshLayout.setXRefreshAndLoadListen(object : XRefreshInterface {
                override fun refreshStart() {
//                    page=1
//                    requestData2()
                }

                override fun loadMoreStart() {
//                    page++
//                    requestData2()
                }

            })
            loading.setLoadingTipXReloadCallback(object: XLoadTip.LoadingTipXReloadCallback{
                override fun reload() {
                    requestData()
                }

            })

        }

    }

    inner class GoldRecyclerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            return fGoldViewHolder(ItemOtherPageFrgBinding.inflate(LayoutInflater.from(activity)))


        }

        override fun getItemCount(): Int = 10

        override fun getItemViewType(position: Int): Int {
            return position
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        }


        inner class fGoldViewHolder(binding: ItemOtherPageFrgBinding) :
            RecyclerView.ViewHolder(binding.root) {
            var mBinding: ItemOtherPageFrgBinding = binding

            init {
                AutoUtils.autoSize(binding.root)

            }
        }


    }

}