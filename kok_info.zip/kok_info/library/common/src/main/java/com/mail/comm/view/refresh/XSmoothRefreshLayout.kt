package com.mail.comm.view.refresh

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import com.mail.comm.R
import com.mail.comm.app.AppConfig
import com.yhz.adaptivelayout.utils.AutoUtils
import me.dkzwm.widget.srl.RefreshingListenerAdapter
import me.dkzwm.widget.srl.SmoothRefreshLayout
import me.dkzwm.widget.srl.extra.footer.MaterialFooter
import me.dkzwm.widget.srl.extra.header.MaterialHeader
import me.dkzwm.widget.srl.indicator.DefaultIndicator
import me.dkzwm.widget.srl.util.PixelUtl

class XSmoothRefreshLayout : SmoothRefreshLayout {

    var refreshAndLoadListen: XRefreshInterface? = null

    constructor(context: Context) : this(context,null)

    constructor(context: Context, attrs: AttributeSet?) : this(context,attrs,0)

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(context)
    }

    fun setXRefreshAndLoadListen(refreshAndLoadListen: XRefreshInterface?) {
        this.refreshAndLoadListen = refreshAndLoadListen
    }

    fun setEnableRefresh(f: Boolean) = setDisableRefresh(!f)

    fun setEnableLoadmore(f: Boolean) = setDisableLoadMore(!f)

    fun startRefresh() = autoRefresh(true)

    fun setIsPinContentView(s: Boolean) = setEnablePinContentView(s)

    fun finishLoadmore() = refreshComplete()

    fun finishRefreshing() =  refreshComplete()

    private fun init(context: Context) {
//        val src = intArrayOf(0xffFE2C55)
        var src: IntArray
        if (AppConfig.model == "wanou"){
             src = intArrayOf(Color.parseColor("#FF69C8"))
        }else{
            src = intArrayOf(-0xff005b)
        }

        val header: MaterialHeader<*> = MaterialHeader<DefaultIndicator>(context)
        header.setColorSchemeColors(src)
        header.setPadding(0, PixelUtl.dp2px(context, 40f), 0, PixelUtl.dp2px(context, 20f))
//        setHeaderView(XRefreshHeaderView<DefaultIndicator>(context))
        setHeaderView(header)
        setEnablePullToRefresh(false)
        setDisableLoadMore(true)
        val footer: MaterialFooter<*> = MaterialFooter<DefaultIndicator>(context)
        footer.setProgressBarColors(src)
        footer.setProgressBarWidth(5)
        footer.setProgressBarRadius(AutoUtils.getPercentWidthSize(20))
//        setFooterView(XRefreshFootView<DefaultIndicator>(context))
        setFooterView(footer)
        setOnRefreshListener(object : RefreshingListenerAdapter() {
            override fun onRefreshing() {
                if (refreshAndLoadListen != null) {
                    refreshAndLoadListen!!.refreshStart()
                }
            }

            override fun onLoadingMore() {
                if (refreshAndLoadListen != null) {
                    refreshAndLoadListen!!.loadMoreStart()
                }
            }
        })
    }

    fun loadMoreReturn() {
        setDisableLoadMore(false)
        //        setDisablePerformRefresh(true);
        setDisablePerformLoadMore(true)
        footerView?.view?.visibility = GONE
    }

    fun loadMoreReturn2() {
        setDisableLoadMore(false)
        setDisablePerformRefresh(true)
        setDisablePerformLoadMore(true)
        setEnableKeepRefreshView(false)
        headerView?.view?.visibility = GONE
        footerView?.view?.visibility = GONE
    }
}