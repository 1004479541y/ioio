package com.mail.comm.base

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import com.mail.comm.app.AppConfig
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.ToastUitl
import com.mail.comm.view.load.XLoadDialog
import com.yhz.adaptivelayout.abs.AbsFrg
import com.yhz.adaptivelayout.abs.ApiListener
import org.xutils.common.util.LogUtil

abstract class BaseFrg: AbsFrg() {

    var rootView: View? = null

    var loadingDialog: XLoadDialog? = null

    abstract fun getLayoutId(): Int

    open fun getLayoutView(): View{
        return View(activity)
    }

    abstract fun initView()

    abstract fun requestData()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if (rootView == null) {

            if(getLayoutId()!=0){
                rootView = inflater.inflate(getLayoutId(), container, false)
            }else{
                rootView = getLayoutView()
            }
            rootView!!.isClickable = true
        }
        initView()
        return rootView
    }

    @SuppressLint("MissingSuperCall")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        typeNet ="onActivityCreated"
        loadingDialog?.destroy()
        requestData()
    }

//    R.anim.abc_grow_fade_in_from_bottom,
//    R.anim.abc_fade_out,
//    R.anim.abc_fade_in,
//    R.anim.abc_shrink_fade_out_from_botto

    fun startActivity(cls: Class<*>,isOverAnim :Boolean= false) {
        startActivity(cls, null)
    }

    fun startActivity(cls: Class<*>, bundle: Bundle?) {
        val intent = Intent(activity, cls)
        bundle?.let { intent.putExtras(it) }
        startActivity(intent)
    }

    fun startActivity(cls: Class<*>, bundle: Bundle?,isAnim: Boolean) {
        val intent = Intent(activity, cls)
        bundle?.let { intent.putExtras(it) }
        startActivity(intent)
        if(activity is BaseAty&&!isAnim){
            activity?.overridePendingTransition(0, 0)
        }
    }


    fun startOverAnimActivity(cls: Class<*>, bundle: Bundle?,vararg sharedElements:Pair<View, String>) {
        val intent = Intent(activity, cls)
        bundle?.let { intent.putExtras(it) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val activityOptions = ActivityOptionsCompat.makeSceneTransitionAnimation(requireActivity(), *sharedElements)
            ActivityCompat.startActivity( requireActivity(), intent, activityOptions.toBundle())
        }else{
            startActivity(cls,bundle)
        }
    }

    fun transition(view: View,cls: Class<*>,bundle: Bundle?) {
        if (Build.VERSION.SDK_INT < 21) {
            val intent = Intent(activity, cls)
            bundle?.let { intent.putExtras(it) }
            val options = ActivityOptionsCompat.makeSceneTransitionAnimation(requireActivity(), view,"d")
            startActivity(intent, options.toBundle())
        }
    }

    fun startActivityForResult(cls: Class<*>, requestCode: Int) {
        startActivityForResult(cls, null, requestCode)
    }

     fun startActivityForResult(cls: Class<*>, bundle: Bundle?, requestCode: Int) {
        val intent = Intent(activity, cls)
        bundle?.let { intent.putExtras(it) }
        startActivityForResult(intent, requestCode)
        if(activity is BaseAty){
//            activity?.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
    }

    fun startActivityForResult(cls: Class<*>, bundle: Bundle?, requestCode: Int,isAnim:Boolean) {
        val intent = Intent(activity, cls)
        bundle?.let { intent.putExtras(it) }
        startActivityForResult(intent, requestCode)
        if(activity is BaseAty&&!isAnim){
            activity?.overridePendingTransition(0, 0)
        }
    }

    fun showToastS(text: String?) = ToastUitl.showShort( text)

    fun showToastL(text: String?) = ToastUitl.showLong( text)

    fun startProgressDialog() {
        if (loadingDialog == null) loadingDialog = XLoadDialog()
        loadingDialog?.showDialogForLoading(activity)
    }

    fun stopProgressDialog() = loadingDialog?.cancelDialogForLoading()

    @SuppressLint("MissingSuperCall")
    override fun onDestroy() {
        super.onDestroy()
        typeNet = "onDestroy"
        loadingDialog?.destroy()
    }

    override fun onComplete(var2: String?, type: String?) {
        var map = JSONUtils.parseKeyAndValueToMap(var2)
        LogUtil.e("onComplete2=========" + type+",,,,"+var2)
        if (map["code"] == "200"&& AppConfig.debug) {
            var str = AESCBCCrypt.aesDecrypt(map["data"])
            MyUtils2.log("onComplete3333","onComplete3=======" + type+",,,,"+ str)
        }
    }

    override fun onPause() {
        super.onPause()
        ToastUitl.destroy()
    }

}