package com.mail.comm.net

import android.text.TextUtils
import android.widget.Toast
import com.mail.comm.app.AppConfig
import com.mail.comm.netretrofit.ApiRetrofit
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.NetworkUtils
import com.yhz.adaptivelayout.abs.ApiListener
import org.json.JSONObject
import org.xutils.common.Callback.*
import org.xutils.common.util.LogUtil
import org.xutils.ex.HttpException
import org.xutils.http.RequestParams
import org.xutils.x
import java.util.*

class ApiTool {

    var params: RequestParams? = null
    var type: String? = null

    fun getApiPing(params: RequestParams, apiListener: ApiListener?, type: String?): Cancelable {
        this.params = params
        this.type = type
        params.connectTimeout = 1000 * 5
        params.readTimeout = 1000 * 5
        params.maxRetryCount = 0
        return x.http().get(params, DefaultRequestCallBack(apiListener))
    }

    fun postApiFile(params: RequestParams, apiListener: ApiListener?, type: String?): Cancelable {
        this.params = params
        this.type = type
        params.connectTimeout = 1000 * 30
        return x.http().post(params, DefaultRequestCallBack(apiListener, true))
    }

    fun getApi(params: RequestParams, apiListener: ApiListener?, request_name: String?) {
        ApiRetrofit().postApi(params.uri, getMapBodyGet(params), getMapHead(), apiListener!!, "get", request_name!!, true)
    }

    fun postApi(params: RequestParams, apiListener: ApiListener?, request_name: String?, isShowError: Boolean) {
        ApiRetrofit().postApi(params.uri, getMapBody(params), getMapHead(), apiListener!!, "post", request_name!!, isShowError)
    }

    fun postApi2(params: RequestParams, apiListener: ApiListener?, type: String?) {
        postApi(params, apiListener, type, true)
        // HashMap<String,String> map_body = getMapBody(params);
//        HashMap<String,String> map_head= getMapHead();
//        new ApiRetrofit().postApi(params.getUri(),map_body,map_head, apiListener, type, true);
//        this.params = params;
//        this.type = type;
//        params.setConnectTimeout(7000);
//
//        HashMap<String,String> map = new HashMap();
//        map.put("device_type", "A");
//        map.put("device_no", MyUtils2.getAndroidId(x.app()));
//        map.put("version", MyUtils2.getAppVersionName());
//        if (!TextUtils.isEmpty(MyUtils2.getToken())){
//            map.put("token",  MyUtils2.getToken());
//        }
//
//        String singHeader = DataManager.singPostBody( new JSONObject(map));
//        params.setHeader("X-TOKEN",singHeader);
//        LogUtil.e("initParams head ="+ new JSONObject(map));
//        initParams(params);
//        x.http().post(params, new DefaultRequestCallBack(apiListener));
//        return x.http().post(params, new DefaultRequestCallBack(apiListener));
    }

    fun getMapBody(params: RequestParams): HashMap<String, String> {
        val list = params.bodyParams
        val map = HashMap<String, String>()
        for (i in list.indices) {
            map[list[i].key] = list[i].value.toString()
        }
        val data = DataManager.singPostBody(JSONObject(map as Map<*, *>))
        LogUtil.e("initParams boby==" + AESCBCCrypt.aesDecrypt(data))
        map.clear()
        map["handshake"] = AppConfig.handshake
        map["data"] = data
        return map
    }

    fun getMapBodyGet(params: RequestParams): HashMap<String, String> {
        val list = params.queryStringParams
        val map = HashMap<String, String>()
        for (i in list.indices) {
            map[list[i].key] = list[i].value.toString()
        }
        return map
    }

    fun getMapHead(): HashMap<String, String> {
        var map = HashMap<String, String>()
        map["device_type"] = "A"
        map["device_no"] = MyUtils2.getAndroidId(x.app())
        map["version"] = MyUtils2.getAppVersionName()
        if (!TextUtils.isEmpty(MyUtils2.getToken())) {
            map["token"] = MyUtils2.getToken()
        }
        val singHeader = DataManager.singPostBody(JSONObject(map as Map<*, *>))
        map.clear()
        map["X-TOKEN"] = singHeader
        return map
    }

//    fun initParams(params: RequestParams) {
//        val list = params.bodyParams
//        val map: HashMap<*, *> = HashMap<String, String>()
//        for (keyValue in list) {
//            map[keyValue.key] = keyValue.value
//        }
//        val data = DataManager.singPostBody(JSONObject(map))
//        LogUtil.e("initParams boby==" + AESCBCCrypt.aesDecrypt(data))
//        map.clear()
//        map["handshake"] = AppConfig.handshake
//        map["data"] = data
//        params.clearParams()
//        params.bodyContent = JSONObject(map).toString()
//    }

    private inner class DefaultRequestCallBack : ProgressCallback<String?> {
         var apiListener: ApiListener?
         var isShowError = false

        constructor(apiListener: ApiListener?) {
            this.apiListener = apiListener
        }

        constructor(apiListener: ApiListener?, isShowError: Boolean) {
            this.apiListener = apiListener
            this.isShowError = isShowError
        }

        override fun onSuccess(result: String?) {

            try {
                apiListener?.onCompleteChild(result, type)
            } catch (var4: Exception) {

            }
        }

        override fun onError(ex: Throwable, isOnCallback: Boolean) {
            apiListener?.onExceptionTypeChild(type)
            if (!NetworkUtils.isConnected(x.app())) {
                Toast.makeText(x.app(), "网络未连接", Toast.LENGTH_SHORT).show()
                return
            }
            if (ex is HttpException) {
                if (isShowError) {
                    Toast.makeText(x.app(), ex.errorCode + ":" + ex.message, Toast.LENGTH_LONG).show()
                }
            } else {
                if (isShowError) {
                    Toast.makeText(x.app(), ex.message, Toast.LENGTH_LONG).show()
                }
            }
        }

        override fun onCancelled(cex: CancelledException) {}
        override fun onFinished() {}
        override fun onWaiting() {}
        override fun onStarted() {}
        override fun onLoading(total: Long, current: Long, isDownloading: Boolean) {
            apiListener?.onLoading(type!!, total, current, isDownloading)
            LogUtil.e("onLoading====total=$total,current=$current,isDownloading$isDownloading")
        }
    }
}