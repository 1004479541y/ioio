package com.mail.comm.base

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mail.comm.app.AppManager
import com.yhz.adaptivelayout.abs.AbsAty
import com.yhz.adaptivelayout.abs.ApiListener
import com.yhz.adaptivelayout.abs.LifeCycleListener
import kotlinx.coroutines.CoroutineScope

abstract class AbsViewHolder(context: Context?, parentView: ViewGroup?) : LifeCycleListener, ApiListener {

    var mTag: String

    var mContext: Context?

    var mParentView: ViewGroup?

    var contentView: View? = null

    abstract fun init()

    abstract fun  getLayoutId():Int

    abstract fun  getLayoutView():View

    init {
        mTag = javaClass.simpleName
        mContext = context
        mParentView = parentView
        if (getLayoutId() == 0) {
            contentView = getLayoutView()
        } else {
            contentView = LayoutInflater.from(context).inflate(getLayoutId(), mParentView, false)
        }
        init()
    }


    fun <T : View?> findViewById(res: Int): T {
        return contentView!!.findViewById(res)
    }

    fun addToParent() {
        if (mParentView != null && contentView != null) {
            mParentView!!.addView(contentView)
        }
    }

    fun removeFromParent() {
        val parent = contentView!!.parent
        if (parent != null) {
            (parent as ViewGroup).removeView(contentView)
        }
    }

    /**
     * 订阅Activity的生命周期
     */
    fun subscribeActivityLifeCycle() {
        if (mContext is AbsAty) {
            (mContext as AbsAty).addLifeCycleListener(this)
        }
    }

    /**
     * 取消订阅Activity的生命周期
     */
    fun unSubscribeActivityLifeCycle() {
        if (mContext is AbsAty) {
            (mContext as AbsAty).removeLifeCycleListener(this)
        }
    }

    fun finishAcitivty() {
        if (mContext != null && mContext is Activity) {
            AppManager.getInstance().killActivity(mContext as Activity?)
        }
    }

    override fun onCreate() {}
    override fun onStart() {}
    override fun onReStart() {}
    override fun onResume() {}
    override fun onPause() {}
    override fun onStop() {}
    override fun onDestroy() {}

    override fun onComplete(var2: String?, type: String?) {}

    override fun onCompleteChild(var2: String?, type: String?) {
        onComplete(var2, type)
    }

    override fun onExceptionType(type: String?) {}

    override fun onExceptionTypeChild(type: String?) {
        onExceptionType(type)
    }

    override fun onLoading(s: String, l: Long, l1: Long, b: Boolean) {}

    override fun getCoroutineScope(): CoroutineScope? {
        if (mContext is AppCompatActivity){
            return  (mContext as AppCompatActivity).lifecycleScope
        }
        return  null
    }

}