package com.mail.comm.app

import android.app.Application
import com.lzy.okgo.OkGo
import com.lzy.okgo.cache.CacheEntity
import com.lzy.okgo.cache.CacheMode
import com.lzy.okgo.cookie.CookieJarImpl
import com.lzy.okgo.cookie.store.DBCookieStore
import com.lzy.okgo.interceptor.HttpLoggingInterceptor
import com.mail.comm.utils.MyUtils
import com.yhz.adaptivelayout.config.AutoLayoutConifg
import okhttp3.OkHttpClient
import org.xutils.x
import java.util.concurrent.TimeUnit
import java.util.logging.Handler
import java.util.logging.Level


open class BaseApp() : Application() {

    var map_info = HashMap<String, String>()

    var list = ArrayList<HashMap<String,String>>()

    companion object {
        var instance: BaseApp? = null
    }

    fun addOneNoticeMsg(msg:HashMap<String,String>){
//        if (list.size>50){
//            var list1 = ArrayList<HashMap<String,String>>()
//            for (index in 0..40){
//                list1.add(list[index])
//            }
//            list.clear()
//            list.addAll(list1)
//        }
//        list.add(msg)
        list.clear()
        list.add(msg)
    }

    fun getAllNoticeMsg()= list

    fun getEndNoticeTime():String{
        var time_end= ""
        if (list==null||list.size ==0){
            return time_end
        }
         time_end = list[0]["time_end"].toString()
        return time_end
    }

    fun clearNoticeMsg(){
        list.clear()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
//        AutoLayoutConifg.getInstance().useDeviceSize()
        x.Ext.init(this)
        x.Ext.setDebug(AppConfig.debug)
        initOkGo()
        closeAndroid10Dialog()
    }

    fun getOneMapData(key: String): String {
        var value = ""
        if (map_info.containsKey(key)) {
            value = map_info[key]!!
        } else {
            value = MyUtils.getInfoDetails(this, key)
            map_info[key]=value
        }
        return value
    }

    fun saveOneMapData(key:String,value: String?){
        if (value == null||key==null){
            return
        }
        map_info[key]=value
        MyUtils.saveInfoDetailsSp(this,key,value)
    }

    private fun initOkGo() {
        val builder = OkHttpClient.Builder()
        //log相关
        val loggingInterceptor = HttpLoggingInterceptor("OkGo")
        loggingInterceptor.setPrintLevel(HttpLoggingInterceptor.Level.BODY) //log打印级别，决定了log显示的详细程度
        loggingInterceptor.setColorLevel(Level.INFO) //log颜色级别，决定了log在控制台显示的颜色
        builder.addInterceptor(loggingInterceptor) //添加OkGo默认debug日志
        builder.readTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS) //全局的读取超时时间
        builder.writeTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS) //全局的写入超时时间
        builder.connectTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS) //全局的连接超时时间
        builder.cookieJar(CookieJarImpl(DBCookieStore(this))) //使用数据库保持cookie，如果cookie不过期，则一直有效
        OkGo.getInstance().init(this) //必须调用初始化
            .setOkHttpClient(builder.build()) //建议设置OkHttpClient，不设置会使用默认的
            .setCacheMode(CacheMode.NO_CACHE) //全局统一缓存模式，默认不使用缓存，可以不传
            .setCacheTime(CacheEntity.CACHE_NEVER_EXPIRE).retryCount = 3 //全局统一超时重连次数，默认为三次，那么最差的情况会请求4次(一次原始请求，三次重连请求)，不需要可以设置为0
        //                .addCommonHeaders(headers)                      //全局公共头
//                .addCommonParams(params);                       //全局公共参数
    }

    fun closeAndroid10Dialog() {
        try {
            val aClass = Class.forName("android.content.pm.PackageParser\$Package")
            val declaredConstructor = aClass.getDeclaredConstructor(
                String::class.java
            )
            declaredConstructor.setAccessible(true)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            val cls = Class.forName("android.app.ActivityThread")
            val declaredMethod = cls.getDeclaredMethod("currentActivityThread")
            declaredMethod.isAccessible = true
            val activityThread = declaredMethod.invoke(null)
            val mHiddenApiWarningShown = cls.getDeclaredField("mHiddenApiWarningShown")
            mHiddenApiWarningShown.isAccessible = true
            mHiddenApiWarningShown.setBoolean(activityThread, true)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }



}