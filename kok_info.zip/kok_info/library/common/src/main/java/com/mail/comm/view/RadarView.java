package com.mail.comm.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.yhz.adaptivelayout.config.AutoLayoutConifg;
import com.yhz.adaptivelayout.utils.AutoUtils;


public class RadarView extends View {


    private Paint mPaint;

    public RadarView(Context context) {
        this(context, null);
    }

    public RadarView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RadarView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public RadarView(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }


    public void init() {
        mPaint = new Paint();
        mPaint.setColor(Color.parseColor("#1000E5FF"));
        mPaint.setStrokeWidth(4);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setAntiAlias(true);
//        mPaint.setBitmapFilter(true)
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
//      setMeasuredDimension(with, with);
    }

    int with = AutoLayoutConifg.getInstance().getScreenWidth();

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int centerX = canvas.getWidth()/2;
        int centery = canvas.getHeight()/2;

//        canvas.drawColor(Color.parseColor("#ffffff"));
//        canvas.drawCircle(centerX, centery, AutoUtils.getPercentWidthSize(150), mPaint);
        canvas.drawCircle(centerX, centery, AutoUtils.getPercentWidthSize(400), mPaint);
        canvas.drawCircle(centerX, centery, AutoUtils.getPercentWidthSize(600), mPaint);
//        canvas.drawCircle(with / 2, with / 2, AutoUtils.getPercentWidthSize(600), mPaint);
//        canvas.drawCircle(with / 2, with / 2, AutoUtils.getPercentWidthSize(900), mPaint);
    }
}
