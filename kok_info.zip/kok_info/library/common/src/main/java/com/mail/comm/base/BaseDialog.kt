package com.mail.comm.base

import android.app.Dialog
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.mail.comm.app.AppConfig
import com.mail.comm.app.AppManager
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.yhz.adaptivelayout.abs.ApiListener
import kotlinx.coroutines.CoroutineScope

open class BaseDialog(context: AppCompatActivity): Dialog(context), ApiListener {

     var baseAty = context

    override fun getCoroutineScope(): CoroutineScope? {
        return  baseAty.lifecycleScope
    }
    override fun onComplete(var2: String?, type: String?) {
        Log.e("onComplete2=========","$type,,,,$var2")
        var map = JSONUtils.parseKeyAndValueToMap(var2)
        if (type == "ping") {
            return
        }

        if (!map.containsKey("code")){
            return
        }

        if (map["code"] != "200" && map["code"] != "500" && map["code"] != "0") {
//            Toast.makeText(this,"服务器异常：${map["code"]}：${map["message"]}",Toast.LENGTH_SHORT).show()
//            AppManager.getInstance().killAllActivity()
//            exitProcess(0)
            AppManager.getInstance().AppExit(baseAty)
            return
        }

        if (type == "version/update"||type=="area/json") {
            return
        }

        if (map["code"] == "200"&& AppConfig.debug) {
            var str = AESCBCCrypt.aesDecrypt(map["data"])
            MyUtils2.log("onComplete3=====","onComplete3=======" + type+",,,,"+ str)
        }
    }

    override fun onCompleteChild(var2: String?, type: String?) {
        onComplete(var2 ,type)
    }

    override fun onExceptionType(type: String?) {
    }

    override fun onExceptionTypeChild(type: String?) {
        onExceptionType(type)
    }

    override fun onLoading(type: String, total: Long, current: Long, isDownloading: Boolean) {
    }


}