package com.mail.comm.base

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.transition.Transition
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.core.view.ViewCompat
import androidx.viewbinding.ViewBinding
import com.mail.comm.app.AppConfig
import com.mail.comm.app.AppManager
import com.mail.comm.app.AppStatusManager
import com.mail.comm.net.AESCBCCrypt
import com.mail.comm.utils.JSONUtils
import com.mail.comm.utils.MyUtils2
import com.mail.comm.utils.ToastUitl
import com.mail.comm.view.load.XLoadDialog
import com.yhz.adaptivelayout.abs.AbsAty
import com.yhz.adaptivelayout.utils.AutoUtils
import kotlin.system.exitProcess

abstract class BaseAty: AbsAty() {

    var isTwoBack: Boolean = false

    var firstTime: Long = 0

    var isAnimFish = "1"  //1 手动 2系统 3无

    var isAnimOver = false

    var loadingDialog: XLoadDialog? = null

    var mBaseBinding: ViewBinding?=null


    abstract fun initView()

    abstract fun requestData()

    open fun getLayoutId(): Int{
        return  0
    }

    open fun getLayoutView(): View?{
        return null
    }

    open fun getViewBinding(): ViewBinding?{
        return  mBaseBinding
    }

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (AppStatusManager.getInstance().appStatus !== 1) {
            Toast.makeText(this,"请重启app",Toast.LENGTH_LONG).show()
            protectApp()
            return
        }
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT;//竖屏
        typeNet = "onCreate"


        if(getLayoutId()!=0){
            setContentView(getLayoutId())
        }else{
            if (getLayoutView()!==null){
                setContentView(getLayoutView())
            }else{
                setContentView(getViewBinding()?.root)
            }

        }
        AppManager.getInstance().addActivity(this)
        window.navigationBarColor = Color.parseColor("#ffffff")
        setStatusColor("#ffffff")
        setAndroidNativeLightStatusBar(true)
        loadingDialog?.destroy()
        initView()
        if (!isAnimOver){
            requestData()
        }
    }

    fun setEnableOverAnim(isAnimOver:Boolean){
        this.isAnimOver = isAnimOver
    }

    fun initOverAnim(list:Array<View>, list2:Array<String>){
        for (i in list.indices){
            ViewCompat.setTransitionName(list[i], list2[i])
        }
        addTransitionListener()
    }

    fun addTransitionListener(): Boolean {
        val transition = window.sharedElementEnterTransition
        if (transition != null) {
            transition.addListener(object : Transition.TransitionListener {
                override fun onTransitionEnd(transition: Transition) {
                    requestData()
                    transition.removeListener(this)
                }

                override fun onTransitionStart(transition: Transition) {
                }

                override fun onTransitionCancel(transition: Transition) {
                    transition.removeListener(this)
                }

                override fun onTransitionPause(transition: Transition) {
                }

                override fun onTransitionResume(transition: Transition) {
                }
            })
            return true
        }
        return false
    }

    private fun protectApp() {
        AppManager.getInstance().killAllActivity()
        exitProcess(0)
    }

     fun setStatusColor(color: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.parseColor(color)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.parseColor(color)
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onPause() {
        super.onPause()
        ToastUitl.destroy()
    }

    fun setAndroidNativeLightStatusBar( dark: Boolean) {
        val decor: View = window.decorView
        if (dark) {
            decor.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            decor.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    fun setTranslanteBar() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val window = window
                val decorView = window.decorView
                val option =
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                decorView.systemUiVisibility = option
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                window.statusBarColor = Color.TRANSPARENT
            } else {
                val window = window
                val attributes = window.attributes
                val flagTranslucentStatus = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                attributes.flags = attributes.flags or flagTranslucentStatus
                window.attributes = attributes
            }
        }
    }

    fun startActivity(cls: Class<*>) {
        startActivity(cls, null)
    }

    fun startActivity(cls: Class<*>, bundle: Bundle?,isAnim :Boolean = true) {
        val intent = Intent(this, cls)
        bundle?.let { intent.putExtras(it) }
        startActivity(intent)
        if (isAnim){
//            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }else{
            overridePendingTransition(0, 0)
        }
    }

    fun startOverAnimActivity(cls: Class<*>, bundle: Bundle?,vararg sharedElements: Pair<View, String>) {
        val intent = Intent(this, cls)
        bundle?.let { intent.putExtras(it) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val activityOptions = ActivityOptionsCompat.makeSceneTransitionAnimation(this, *sharedElements)
            ActivityCompat.startActivity( this, intent, activityOptions.toBundle())
        }else{
            startActivity(cls,bundle)
        }
    }

    fun startActivityForResult(cls: Class<*>, requestCode: Int) {
        startActivityForResult(cls, null, requestCode)
    }

    fun startActivityForResult(cls: Class<*>, bundle: Bundle?, requestCode: Int,isAnim :Boolean = true) {
        val intent = Intent(this, cls)
        bundle?.let { intent.putExtras(it) }
        startActivityForResult(intent, requestCode)

        if (isAnim){
//            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }else{
            overridePendingTransition(0, 0)
        }
    }

    fun showToastS(text: String?) = ToastUitl.showShort(text)

    fun showToastL(text: String?) = ToastUitl.showLong(text)

    fun startProgressDialog(text :String="",b:Boolean = true) {
        if (loadingDialog == null) loadingDialog = XLoadDialog()
        loadingDialog?.showDialogForLoading(this)
        loadingDialog?.setText(text)
        loadingDialog?.setCancelable(b)
    }

    fun stopProgressDialog() = loadingDialog?.cancelDialogForLoading()

    fun setBackTwo(isTwoBack: Boolean) {
        this.isTwoBack = isTwoBack
    }

    override fun finish() {
        super.finish()
        when(isAnimFish){

            "1" ->{
//                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
            }
            "2" ->{

            }
            "3"->{
                overridePendingTransition(0,0)
            }
        }
//        overridePendingTransition(R.anim.abc_fade_out, R.anim.abc_shrink_fade_out_from_bottom)
    }

    fun finshPage(isAnim :String = "1"){
        isAnimFish = isAnim
        finish()
    }

    @SuppressLint("MissingSuperCall")
    override fun onDestroy() {
        super.onDestroy()
        typeNet = "onDestroy"
        AppManager.getInstance().removeActivity(this)
        loadingDialog?.destroy()
    }

    override fun onBackPressed() {
        if (isTwoBack) {
            if (System.currentTimeMillis() - firstTime < 3000) {
                AppManager.getInstance().AppExit(this)
            } else {
                firstTime = System.currentTimeMillis()
                showToastS("再按一次返回桌面")
            }
        } else {
            finishAfterTransition()
        }
    }


    //非沉淀状态栏   背景-资源文件
    fun initTopview(relay: RelativeLayout?, bgColor:String = "#ffffff") {
        val lp = relay?.layoutParams as RelativeLayout.LayoutParams
        lp.height = AutoUtils.getPercentHeightSize(130)
        relay.layoutParams = lp
        relay.setBackgroundColor(Color.parseColor(bgColor))
    }

    override fun onComplete(var2: String?, type: String?) {
        super.onComplete(var2, type)
        Log.e("onComplete2=========","$type,,,,$var2")
        var map = JSONUtils.parseKeyAndValueToMap(var2)
        if (type == "ping") {
            return
        }

        if (!map.containsKey("code")){
            return
        }

//        if (map["code"] != "200" && map["code"] != "500" && map["code"] != "0"&& map["code"] != "206"&& map["code"] != "1005"&& map["code"] != "1006") {
        if (map["code"]=="401"||map["code"]=="403"||map["code"]=="4999") {
            showToastS(map["code"])
            AppManager.getInstance().AppExit(this)
            return
        }

        if (type == "version/update"||type=="area/json") {
            return
        }

        if (map["code"] == "200"&& AppConfig.debug) {
            var str = AESCBCCrypt.aesDecrypt(map["data"])
            MyUtils2.log("onComplete3=====","onComplete3=======" + type+",,,,"+ str)
        }
    }

}